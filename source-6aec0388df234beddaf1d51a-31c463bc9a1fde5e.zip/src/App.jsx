import React, { useState, useEffect, useMemo } from 'react';
import {
  initializeApp,
  getAuth,
  signInWithCustomToken,
  signInAnonymously,
  onAuthStateChanged,
  getFirestore,
  collection,
  doc,
  setDoc,
  deleteDoc,
  onSnapshot,
  verifyAdminPin,
  restoreAdminSession,
  clearAdminSession
} from './lib/store.js';
import { Snowfall, ChristmasLights, InteractiveSleigh, ChristmasBanner } from './components/Christmas.jsx';
import { 
  Ticket, 
  Search, 
  Trophy, 
  Plus, 
  Upload, 
  Download, 
  Trash2, 
  Edit3, 
  CheckCircle2, 
  AlertCircle, 
  UserCheck, 
  Sparkles, 
  X, 
  Filter, 
  RefreshCw, 
  Award, 
  HelpCircle, 
  Copy, 
  Lock, 
  KeyRound, 
  Share2, 
  Eye, 
  EyeOff, 
  Settings, 
  ShieldCheck,
  BarChart3,
  Crown,
  Medal,
  TrendingUp,
  ExternalLink
} from 'lucide-react';

// Inicialización de la capa de datos (Netlify Functions + Netlify Database)
const app = initializeApp();
const auth = getAuth(app);
const db = getFirestore(app);
const appId = 'rifa2026navidad';
const __initial_auth_token = undefined;

export default function App() {
  // Estados de Autenticación y Datos
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const [tickets, setTickets] = useState([]);
  const [winners, setWinners] = useState([]);
  
  // Estados de Roles, Permisos y Configuración (Modo Consulta vs Administrador)
  const [isAdminUnlocked, setIsAdminUnlocked] = useState(false);
  const [previewAsGuest, setPreviewAsGuest] = useState(false);
  const [appConfig, setAppConfig] = useState({
    adminPin: '1234',
    ownerUid: '',
    raffleTitle: 'Control de Rifas y Sorteos'
  });

  // Permiso efectivo actual (Si el admin activó "Vista Previa como Invitado", actúa como solo lectura)
  const canEdit = isAdminUnlocked && !previewAsGuest;

  // Estados de Modales de Seguridad y Compartir
  const [isPinModalOpen, setIsPinModalOpen] = useState(false);
  const [pinInput, setPinInput] = useState('');
  const [isSettingsModalOpen, setIsSettingsModalOpen] = useState(false);
  const [settingsForm, setSettingsForm] = useState({
    newPin: '',
    raffleTitle: ''
  });
  const [isShareModalOpen, setIsShareModalOpen] = useState(false);

  // Estados de Interfaz y Navegación
  const [activeTab, setActiveTab] = useState('buscador'); // 'buscador', 'directorio', 'ganadores'
  const [toast, setToast] = useState(null);
  
  // Estados del Buscador Principal
  const [searchNumber, setSearchNumber] = useState('');
  
  // Estados para Formulario de Boleta (Crear/Editar) con las 7 columnas exactas
  const [isTicketModalOpen, setIsTicketModalOpen] = useState(false);
  const [ticketForm, setTicketForm] = useState({
    id: '',
    paquete: '',
    boleta: '',
    numero1: '',
    numero2: '',
    numero3: '',
    numero4: '',
    responsable: ''
  });
  const [isEditingTicket, setIsEditingTicket] = useState(false);

  // Estados para Importación Masiva (Lote Boletas - 7 columnas)
  const [isBulkModalOpen, setIsBulkModalOpen] = useState(false);
  const [bulkText, setBulkText] = useState('');
  const [isImporting, setIsImporting] = useState(false);

  // Estados para Importación Masiva (Lote Ganadores)
  const [isBulkWinnerModalOpen, setIsBulkWinnerModalOpen] = useState(false);
  const [bulkWinnerText, setBulkWinnerText] = useState('');
  const [isImportingWinners, setIsImportingWinners] = useState(false);

  // Estados de Filtros del Directorio (Estilo Excel)
  const [filterPaquete, setFilterPaquete] = useState('Todos');
  const [filterResponsable, setFilterResponsable] = useState('Todos');
  const [directorySearch, setDirectorySearch] = useState('');

  // Estados para Formulario de Ganadores / Premios Sorteados
  const [winnerForm, setWinnerForm] = useState({
    id: '',
    drawNumber: '',
    prizeDescription: '',
    lottery: '',
    drawDate: new Date().toISOString().split('T')[0],
    winningNumber: '',
    sellerName: '',
    ticketInfo: ''
  });
  const [isEditingWinner, setIsEditingWinner] = useState(false);
  const [winnerLookupStatus, setWinnerLookupStatus] = useState(null); // 'found', 'not_found', null
  const [quickAssignModal, setQuickAssignModal] = useState({
    isOpen: false,
    draw: null,
    winningNumber: '',
    sellerName: '',
    ticketInfo: '',
    lookupStatus: null
  });

  // Estado para Modal de Confirmación de Eliminación
  const [deleteConfirm, setDeleteConfirm] = useState({ isOpen: false, type: '', id: '', label: '' });

  // Mostrar notificación temporal
  const showNotification = (message, type = 'success') => {
    setToast({ message, type });
    setTimeout(() => setToast(null), 3500);
  };

  // Normalizador auxiliar para obtener los 4 números de una boleta (compatible también con registros antiguos)
  const getTicketNumbers = (t) => {
    return [
      t.numero1 !== undefined ? String(t.numero1).trim() : (t.number !== undefined ? String(t.number).trim() : ''),
      t.numero2 !== undefined ? String(t.numero2).trim() : '',
      t.numero3 !== undefined ? String(t.numero3).trim() : '',
      t.numero4 !== undefined ? String(t.numero4).trim() : ''
    ];
  };

  const getTicketResponsable = (t) => {
    return t.responsable || t.sellerName || t.buyerName || 'Sin Responsable';
  };

  const getTicketBoleta = (t) => {
    return t.boleta !== undefined && t.boleta !== '' ? String(t.boleta) : String(t.number || t.id || '');
  };

  const getTicketPaquete = (t) => {
    return t.paquete !== undefined && t.paquete !== '' ? String(t.paquete) : '1';
  };

  // Función central para buscar un número jugado/consultado dentro de Numero 1, Numero 2, Numero 3 o Numero 4
  const findTicketByPlayedNumber = (rawNum) => {
    const clean = String(rawNum || '').trim().replace(/^#/, '').toLowerCase();
    if (!clean) return null;

    for (const t of tickets) {
      const nums = getTicketNumbers(t);
      const matchedIndex = nums.findIndex(n => n && n.toLowerCase() === clean);
      if (matchedIndex !== -1) {
        return {
          ticket: t,
          matchedColumn: `Numero ${matchedIndex + 1}`,
          matchedValue: nums[matchedIndex]
        };
      }
    }
    return null;
  };

  // 1. Efecto de Autenticación (Regla 3)
  useEffect(() => {
    const initAuth = async () => {
      try {
        if (typeof __initial_auth_token !== 'undefined' && __initial_auth_token) {
          await signInWithCustomToken(auth, __initial_auth_token);
        } else {
          await signInAnonymously(auth);
        }
      } catch (error) {
        console.error("Error de autenticación:", error);
        showNotification("Error al conectar con el servidor de autenticación", "error");
      }
    };
    initAuth();

    const unsubscribe = onAuthStateChanged(auth, (currentUser) => {
      setUser(currentUser);
      if (!currentUser) setLoading(false);
    });
    return () => unsubscribe();
  }, []);

  // 1b. Restaurar sesión de administrador guardada en este navegador
  useEffect(() => {
    restoreAdminSession().then((res) => {
      if (res.ok) {
        setAppConfig(prev => ({ ...prev, adminPin: res.pin }));
        setIsAdminUnlocked(true);
      }
    });
  }, []);

  // 2. Efecto de Escucha de Datos en Firestore (Reglas 1 y 2)
  useEffect(() => {
    if (!user) return;

    setLoading(true);
    const ticketsRef = collection(db, 'artifacts', appId, 'public', 'data', 'rifa_tickets');
    const winnersRef = collection(db, 'artifacts', appId, 'public', 'data', 'rifa_winners');
    const configRef = collection(db, 'artifacts', appId, 'public', 'data', 'rifa_config');

    const unsubTickets = onSnapshot(
      ticketsRef,
      (snapshot) => {
        const list = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
        // Ordenar por Paquete y luego por Boleta numéricamente en memoria
        list.sort((a, b) => {
          const paqCompare = String(a.paquete || '').localeCompare(String(b.paquete || ''), undefined, { numeric: true });
          if (paqCompare !== 0) return paqCompare;
          return String(a.boleta || a.number || '').localeCompare(String(b.boleta || b.number || ''), undefined, { numeric: true });
        });
        setTickets(list);
        setLoading(false);
      },
      (error) => {
        console.error("Error obteniendo boletas:", error);
        showNotification("Error al sincronizar la base de datos de boletas", "error");
        setLoading(false);
      }
    );

    const unsubWinners = onSnapshot(
      winnersRef,
      (snapshot) => {
        const list = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
        // Ordenar por Número de Sorteo numéricamente
        list.sort((a, b) =>
          String(a.drawNumber || '').localeCompare(String(b.drawNumber || ''), undefined, { numeric: true })
        );
        setWinners(list);
      },
      (error) => {
        console.error("Error obteniendo ganadores:", error);
        showNotification("Error al sincronizar el listado de ganadores", "error");
      }
    );

    const unsubConfig = onSnapshot(
      configRef,
      (snapshot) => {
        const mainDoc = snapshot.docs.find(d => d.id === 'main_settings');
        if (mainDoc) {
          const data = mainDoc.data();
          setAppConfig(prev => ({
            adminPin: prev.adminPin,
            ownerUid: data.ownerUid || '',
            raffleTitle: data.raffleTitle || 'Control de Rifas y Sorteos'
          }));
        }
      },
      (error) => {
        console.error("Error obteniendo configuración:", error);
      }
    );

    return () => {
      unsubTickets();
      unsubWinners();
      unsubConfig();
    };
  }, [user]);

  // --- LÓGICA DE AUTENTICACIÓN DE ADMINISTRADOR Y CONFIGURACIÓN ---
  const handleAdminLogin = async (e) => {
    e.preventDefault();
    if (!user) return;

    const cleanPin = pinInput.trim();
    let verification = { ok: false };
    try {
      verification = await verifyAdminPin(cleanPin);
    } catch (err) {
      console.error("Error verificando PIN:", err);
    }
    if (verification.ok) {
      setAppConfig(prev => ({ ...prev, adminPin: verification.pin }));
      setIsAdminUnlocked(true);
      setPreviewAsGuest(false);
      setPinInput('');
      setIsPinModalOpen(false);

      if (!appConfig.ownerUid) {
        try {
          const settingsDocRef = doc(db, 'artifacts', appId, 'public', 'data', 'rifa_config', 'main_settings');
          await setDoc(settingsDocRef, {
            ownerUid: user.uid,
            raffleTitle: appConfig.raffleTitle,
            updatedAt: Date.now()
          });
        } catch (err) {
          console.error("No se pudo inicializar config:", err);
        }
      }
      showNotification("Modo Administrador desbloqueado. Edición habilitada.");
    } else {
      showNotification("PIN incorrecto. Intenta nuevamente.", "error");
    }
  };

  const handleOpenSettings = () => {
    setSettingsForm({
      newPin: appConfig.adminPin,
      raffleTitle: appConfig.raffleTitle
    });
    setIsSettingsModalOpen(true);
  };

  const handleSaveSettings = async (e) => {
    e.preventDefault();
    if (!user || !canEdit) return;

    const cleanPin = String(settingsForm.newPin).trim();
    if (!cleanPin || cleanPin.length < 4) {
      showNotification("El PIN de administrador debe tener al menos 4 caracteres", "error");
      return;
    }

    try {
      const settingsDocRef = doc(db, 'artifacts', appId, 'public', 'data', 'rifa_config', 'main_settings');
      await setDoc(settingsDocRef, {
        adminPin: cleanPin,
        ownerUid: appConfig.ownerUid || user.uid,
        raffleTitle: settingsForm.raffleTitle.trim() || 'Control de Rifas y Sorteos',
        updatedAt: Date.now()
      });
      setIsSettingsModalOpen(false);
      showNotification("Configuración de seguridad actualizada");
    } catch (error) {
      console.error("Error guardando configuración:", error);
      showNotification("Error al guardar la configuración", "error");
    }
  };

  // --- LÓGICA DEL BUSCADOR DE NÚMEROS (Busca en Numero 1, Numero 2, Numero 3, Numero 4 o por N° de Boleta) ---
  const searchResult = useMemo(() => {
    const cleanQuery = searchNumber.trim().replace(/^#/, '');
    if (!cleanQuery) return null;

    // 1. Buscar primero coincidencia exacta dentro de Numero 1, Numero 2, Numero 3 o Numero 4
    const byNumber = findTicketByPlayedNumber(cleanQuery);
    if (byNumber) {
      return {
        ticket: byNumber.ticket,
        matchedColumn: byNumber.matchedColumn,
        matchedValue: byNumber.matchedValue,
        matchType: 'numero'
      };
    }

    // 2. Si no coincide con los 4 números de juego, verificar si buscó por código de Boleta
    const byBoleta = tickets.find(
      t => getTicketBoleta(t).toLowerCase() === cleanQuery.toLowerCase()
    );
    if (byBoleta) {
      return {
        ticket: byBoleta,
        matchedColumn: 'Boleta',
        matchedValue: getTicketBoleta(byBoleta),
        matchType: 'boleta'
      };
    }

    return null;
  }, [searchNumber, tickets]);

  // Verificar si alguno de los 4 números de la boleta consultada ya ganó un sorteo
  const searchedTicketWinnerInfo = useMemo(() => {
    if (!searchResult || !searchResult.ticket) return null;
    const nums = getTicketNumbers(searchResult.ticket).filter(Boolean).map(n => n.toLowerCase());
    return winners.find(w => w.winningNumber && nums.includes(String(w.winningNumber).trim().toLowerCase())) || null;
  }, [searchResult, winners]);

  // --- LÓGICA DE ESTADÍSTICAS Y FILTROS ---
  const stats = useMemo(() => {
    const totalBoletas = tickets.length;
    // Contar cuántos números individuales están asignados (hasta 4 por boleta)
    const totalNumbersAssigned = tickets.reduce((acc, t) => {
      return acc + getTicketNumbers(t).filter(Boolean).length;
    }, 0);
    const uniquePaquetes = [...new Set(tickets.map(t => getTicketPaquete(t)).filter(Boolean))].sort((a, b) =>
      String(a).localeCompare(String(b), undefined, { numeric: true })
    );
    const uniqueResponsables = [...new Set(tickets.map(t => getTicketResponsable(t)).filter(Boolean))].sort();
    const totalWinners = winners.length;

    return {
      totalBoletas,
      totalNumbersAssigned,
      uniquePaquetes,
      uniqueResponsables,
      totalWinners
    };
  }, [tickets, winners]);

  // --- LÓGICA DEL DASHBOARD Y RANKING DE RESPONSABLES CON MÁS PREMIOS VENDIDOS ---
  const dashboardMetrics = useMemo(() => {
    const totalDraws = winners.length;
    const completedDrawsList = winners.filter(
      w => (w.winningNumber && String(w.winningNumber).trim() !== '') || (w.sellerName && String(w.sellerName).trim() !== '')
    );
    const completedDraws = completedDrawsList.length;
    const pendingDraws = Math.max(0, totalDraws - completedDraws);
    const progressPercentage = totalDraws > 0 ? Math.round((completedDraws / totalDraws) * 100) : 0;

    // Contabilizar boletas asignadas por cada responsable en la base de datos
    const ticketsByResp = {};
    tickets.forEach(t => {
      const resp = getTicketResponsable(t).trim();
      if (resp && resp !== 'Sin Responsable' && resp !== 'Sin Asignar') {
        ticketsByResp[resp] = (ticketsByResp[resp] || 0) + 1;
      }
    });

    // Contabilizar premios vendidos por responsable a partir de los sorteos jugados
    const prizesMap = {};
    winners.forEach(w => {
      let seller = (w.sellerName || '').trim();
      if (!seller && w.winningNumber) {
        const match = findTicketByPlayedNumber(w.winningNumber);
        if (match) {
          seller = getTicketResponsable(match.ticket).trim();
        }
      }
      if (seller && seller !== '—' && seller !== 'Por definir') {
        if (!prizesMap[seller]) {
          prizesMap[seller] = {
            responsable: seller,
            prizesCount: 0,
            prizesWon: [],
            totalBoletas: ticketsByResp[seller] || 0
          };
        }
        prizesMap[seller].prizesCount += 1;
        prizesMap[seller].prizesWon.push({
          drawNumber: w.drawNumber || 'Sorteo',
          prize: w.prizeDescription || 'Premio',
          winningNumber: w.winningNumber || '',
          date: w.drawDate || ''
        });
      }
    });

    // Ordenar de mayor a menor por cantidad de premios vendidos (y desempate por total de boletas)
    const rankingList = Object.values(prizesMap).sort((a, b) => {
      if (b.prizesCount !== a.prizesCount) return b.prizesCount - a.prizesCount;
      return b.totalBoletas - a.totalBoletas;
    });

    const top3 = rankingList.slice(0, 3);

    return {
      totalDraws,
      completedDraws,
      pendingDraws,
      progressPercentage,
      rankingList,
      top3
    };
  }, [winners, tickets]);

  const filteredTickets = useMemo(() => {
    return tickets.filter(t => {
      const paq = getTicketPaquete(t);
      const resp = getTicketResponsable(t);
      const bol = getTicketBoleta(t);
      const [n1, n2, n3, n4] = getTicketNumbers(t);

      const matchesPaquete = filterPaquete === 'Todos' || paq === filterPaquete;
      const matchesResponsable = filterResponsable === 'Todos' || resp === filterResponsable;

      const q = directorySearch.trim().toLowerCase();
      const matchesQuery =
        !q ||
        paq.toLowerCase().includes(q) ||
        bol.toLowerCase().includes(q) ||
        n1.toLowerCase().includes(q) ||
        n2.toLowerCase().includes(q) ||
        n3.toLowerCase().includes(q) ||
        n4.toLowerCase().includes(q) ||
        resp.toLowerCase().includes(q);

      return matchesPaquete && matchesResponsable && matchesQuery;
    });
  }, [tickets, filterPaquete, filterResponsable, directorySearch]);

  // --- MANEJADORES DE BOLETAS (7 COLUMNAS: Paquete, Boleta, Numero 1, Numero 2, Numero 3, Numero 4, Responsable) ---
  const openNewTicketModal = (prefillNumber = '') => {
    if (!canEdit) {
      setIsPinModalOpen(true);
      return;
    }
    const nextBoleta = tickets.length + 1;
    setTicketForm({
      id: '',
      paquete: '1',
      boleta: String(nextBoleta),
      numero1: prefillNumber,
      numero2: '',
      numero3: '',
      numero4: '',
      responsable: ''
    });
    setIsEditingTicket(false);
    setIsTicketModalOpen(true);
  };

  const openEditTicketModal = (ticket) => {
    if (!canEdit) {
      setIsPinModalOpen(true);
      return;
    }
    const [n1, n2, n3, n4] = getTicketNumbers(ticket);
    setTicketForm({
      id: ticket.id,
      paquete: getTicketPaquete(ticket),
      boleta: getTicketBoleta(ticket),
      numero1: n1,
      numero2: n2,
      numero3: n3,
      numero4: n4,
      responsable: getTicketResponsable(ticket)
    });
    setIsEditingTicket(true);
    setIsTicketModalOpen(true);
  };

  const handleSaveTicket = async (e) => {
    e.preventDefault();
    if (!user || !canEdit) return;

    const cleanPaquete = String(ticketForm.paquete || '1').trim();
    const cleanBoleta = String(ticketForm.boleta || '').trim();
    const cleanN1 = String(ticketForm.numero1 || '').trim();
    const cleanN2 = String(ticketForm.numero2 || '').trim();
    const cleanN3 = String(ticketForm.numero3 || '').trim();
    const cleanN4 = String(ticketForm.numero4 || '').trim();
    const cleanResp = String(ticketForm.responsable || '').trim();

    if (!cleanBoleta || !cleanN1 || !cleanResp) {
      showNotification("Por favor completa al menos Boleta, Numero 1 y Responsable", "error");
      return;
    }

    const docId = isEditingTicket && ticketForm.id
      ? ticketForm.id
      : `boleta_${cleanPaquete.replace(/[^a-zA-Z0-9]/g, '')}_${cleanBoleta.replace(/[^a-zA-Z0-9]/g, '')}`;

    try {
      const ticketRef = doc(db, 'artifacts', appId, 'public', 'data', 'rifa_tickets', docId);
      await setDoc(ticketRef, {
        paquete: cleanPaquete,
        boleta: cleanBoleta,
        numero1: cleanN1,
        numero2: cleanN2,
        numero3: cleanN3,
        numero4: cleanN4,
        responsable: cleanResp,
        updatedAt: Date.now()
      });

      showNotification(
        isEditingTicket
          ? `Boleta #${cleanBoleta} (Paquete ${cleanPaquete}) actualizada`
          : `Boleta #${cleanBoleta} asignada a ${cleanResp}`
      );
      setIsTicketModalOpen(false);
    } catch (error) {
      console.error("Error guardando boleta:", error);
      showNotification("Hubo un error al guardar la boleta", "error");
    }
  };

  // --- IMPORTACIÓN POR LOTE DE BOLETAS (ESTRUCTURA EXACTA DE 7 COLUMNAS DESDE EXCEL) ---
  const handleBulkImport = async (e) => {
    e.preventDefault();
    if (!user || !canEdit || !bulkText.trim()) return;

    setIsImporting(true);
    const lines = bulkText.split('\n').map(l => l.trim()).filter(Boolean);
    let importedCount = 0;

    try {
      for (const line of lines) {
        const lower = line.toLowerCase();
        // Saltar fila de encabezado si el usuario la copió desde Excel
        if (lower.includes('paquete') && lower.includes('boleta') && lower.includes('responsable')) {
          continue;
        }

        // Soporta tabulación directa desde Excel, punto y coma o coma
        const parts = line.includes('\t')
          ? line.split('\t').map(p => p.trim())
          : line.split(/[;,]/).map(p => p.trim());

        if (parts.length >= 3) {
          const paquete = parts[0] || '1';
          const boleta = parts[1] || String(importedCount + 1);
          const numero1 = parts[2] || '';
          const numero2 = parts[3] || '';
          const numero3 = parts[4] || '';
          const numero4 = parts[5] || '';
          const responsable = parts[6] || parts[parts.length - 1] || 'Sin Asignar';

          if (boleta || numero1) {
            const cleanPaq = String(paquete).replace(/[^a-zA-Z0-9_-]/g, '_');
            const cleanBol = String(boleta).replace(/[^a-zA-Z0-9_-]/g, '_');
            const docId = `boleta_${cleanPaq}_${cleanBol}`;
            const ticketRef = doc(db, 'artifacts', appId, 'public', 'data', 'rifa_tickets', docId);

            await setDoc(ticketRef, {
              paquete,
              boleta,
              numero1,
              numero2,
              numero3,
              numero4,
              responsable,
              updatedAt: Date.now() + importedCount
            });
            importedCount++;
          }
        }
      }
      showNotification(`Se importaron ${importedCount} boletas con sus 4 números exitosamente`);
      setBulkText('');
      setIsBulkModalOpen(false);
    } catch (error) {
      console.error("Error en importación masiva:", error);
      showNotification("Error durante la importación de algunos registros", "error");
    } finally {
      setIsImporting(false);
    }
  };

  // IMPORTACIÓN POR LOTE DE PREMIOS SORTEADOS (Soporta copiar y pegar directo desde Excel)
  const handleBulkWinnerImport = async (e) => {
    e.preventDefault();
    if (!user || !canEdit || !bulkWinnerText.trim()) return;

    setIsImportingWinners(true);
    const lines = bulkWinnerText.split('\n').map(l => l.trim()).filter(Boolean);
    let importedCount = 0;

    try {
      for (const line of lines) {
        const lowerLine = line.toLowerCase();
        if (lowerLine.includes('numero de sorteo') && lowerLine.includes('premio')) {
          continue;
        }

        const parts = line.includes('\t')
          ? line.split('\t').map(p => p.trim())
          : line.split(/[;,]/).map(p => p.trim());

        if (parts.length >= 2) {
          const drawNum = parts[0] || `${winners.length + importedCount + 1}`;
          const prize = parts[1] || '';
          const lottery = parts[2] || '';
          const drawDate = parts[3] || '';
          let col4 = parts[4] || '';
          let col5 = parts[5] || '';

          let winNum = '';
          let seller = '';
          let ticketInfo = '';

          if (col5) {
            seller = col4;
            winNum = col5;
          } else if (col4 && /^\d+$/.test(col4.replace(/^#/, ''))) {
            winNum = col4.replace(/^#/, '');
          } else {
            seller = col4;
          }

          // Si hay número ganador, buscar en las 4 columnas (Numero 1..4) de la base de datos de boletas
          if (winNum) {
            const match = findTicketByPlayedNumber(winNum);
            if (match) {
              seller = getTicketResponsable(match.ticket) || seller;
              ticketInfo = `Boleta #${getTicketBoleta(match.ticket)} (Paquete ${getTicketPaquete(match.ticket)} • ${match.matchedColumn})`;
            }
          }

          const cleanDrawId = String(drawNum).replace(/[^a-zA-Z0-9_-]/g, '_');
          const docId = `sorteo_${cleanDrawId}_${Date.now()}_${importedCount}`;
          const winnerRef = doc(db, 'artifacts', appId, 'public', 'data', 'rifa_winners', docId);
          
          await setDoc(winnerRef, {
            drawNumber: drawNum,
            prizeDescription: prize,
            lottery: lottery,
            drawDate: drawDate,
            winningNumber: winNum,
            sellerName: seller,
            ticketInfo: ticketInfo,
            createdAt: Date.now() + importedCount
          });
          importedCount++;
        }
      }
      showNotification(`Se importaron ${importedCount} premios sorteados correctamente`);
      setBulkWinnerText('');
      setIsBulkWinnerModalOpen(false);
    } catch (error) {
      console.error("Error importando premios sorteados:", error);
      showNotification("Error al importar el listado de premios sorteados", "error");
    } finally {
      setIsImportingWinners(false);
    }
  };

  const handleLoadSampleData = async () => {
    if (!user || !canEdit) return;
    const samples = [
      { paquete: '1', boleta: '1', numero1: '0124', numero2: '2624', numero3: '5124', numero4: '7624', responsable: 'Laura Gómez' },
      { paquete: '1', boleta: '2', numero1: '0389', numero2: '2889', numero3: '5389', numero4: '7889', responsable: 'Laura Gómez' },
      { paquete: '1', boleta: '3', numero1: '0512', numero2: '3012', numero3: '5512', numero4: '8012', responsable: 'Andrés Pérez' },
      { paquete: '2', boleta: '4', numero1: '1045', numero2: '3545', numero3: '6045', numero4: '8545', responsable: 'Camila Torres' },
      { paquete: '2', boleta: '5', numero1: '1490', numero2: '3990', numero3: '6490', numero4: '8990', responsable: 'Carlos Mendoza' },
      { paquete: '2', boleta: '6', numero1: '1907', numero2: '4407', numero3: '6907', numero4: '9407', responsable: 'Diana Marcela Ruiz' }
    ];

    try {
      for (const item of samples) {
        const docId = `boleta_${item.paquete}_${item.boleta}`;
        const ticketRef = doc(db, 'artifacts', appId, 'public', 'data', 'rifa_tickets', docId);
        await setDoc(ticketRef, { ...item, updatedAt: Date.now() });
      }
      showNotification("6 boletas de ejemplo (con 4 números cada una) cargadas correctamente");
    } catch (error) {
      console.error("Error cargando ejemplos:", error);
      showNotification("No se pudieron cargar los datos de ejemplo", "error");
    }
  };

  // --- MANEJADORES DE GANADORES (Busca en Numero 1, Numero 2, Numero 3 y Numero 4) ---
  const handleWinningNumberChange = (val) => {
    const cleanVal = val.trim().replace(/^#/, '');
    const match = findTicketByPlayedNumber(cleanVal);

    if (match) {
      const resp = getTicketResponsable(match.ticket);
      const info = `Boleta #${getTicketBoleta(match.ticket)} (Paquete ${getTicketPaquete(match.ticket)} • ${match.matchedColumn})`;
      setWinnerForm(prev => ({
        ...prev,
        winningNumber: val,
        sellerName: resp,
        ticketInfo: info
      }));
      setWinnerLookupStatus('found');
    } else {
      setWinnerForm(prev => ({
        ...prev,
        winningNumber: val,
        sellerName: isEditingWinner ? prev.sellerName : '',
        ticketInfo: ''
      }));
      setWinnerLookupStatus(cleanVal ? 'not_found' : null);
    }
  };

  const handleSaveWinner = async (e) => {
    e.preventDefault();
    if (!user || !canEdit) return;

    const cleanDraw = winnerForm.drawNumber.trim();
    const cleanPrize = winnerForm.prizeDescription.trim();
    const cleanLottery = winnerForm.lottery.trim();
    const cleanWinNum = String(winnerForm.winningNumber || '').trim().replace(/^#/, '');
    let cleanSeller = winnerForm.sellerName.trim();
    let cleanTicketInfo = winnerForm.ticketInfo || '';

    if (!cleanDraw || !cleanPrize) {
      showNotification("Completa al menos el Numero de Sorteo y el Premio", "error");
      return;
    }

    if (cleanWinNum) {
      const match = findTicketByPlayedNumber(cleanWinNum);
      if (match) {
        if (!cleanSeller) cleanSeller = getTicketResponsable(match.ticket);
        cleanTicketInfo = `Boleta #${getTicketBoleta(match.ticket)} (Paquete ${getTicketPaquete(match.ticket)} • ${match.matchedColumn})`;
      }
    }

    const docId = isEditingWinner && winnerForm.id 
      ? winnerForm.id 
      : `sorteo_${Date.now()}_${cleanDraw.replace(/[^a-zA-Z0-9]/g, '')}`;

    try {
      const winnerRef = doc(db, 'artifacts', appId, 'public', 'data', 'rifa_winners', docId);
      await setDoc(winnerRef, {
        drawNumber: cleanDraw,
        prizeDescription: cleanPrize,
        lottery: cleanLottery,
        drawDate: winnerForm.drawDate,
        winningNumber: cleanWinNum,
        sellerName: cleanSeller,
        ticketInfo: cleanTicketInfo,
        createdAt: isEditingWinner ? (winnerForm.createdAt || Date.now()) : Date.now()
      });

      showNotification(
        isEditingWinner 
          ? `Sorteo ${cleanDraw} actualizado correctamente` 
          : `Sorteo ${cleanDraw} registrado en la lista de premios`
      );

      const nextDrawNum = winners.length + (isEditingWinner ? 1 : 2);
      setWinnerForm({
        id: '',
        drawNumber: `Sorteo #${nextDrawNum}`,
        prizeDescription: '',
        lottery: '',
        drawDate: new Date().toISOString().split('T')[0],
        winningNumber: '',
        sellerName: '',
        ticketInfo: ''
      });
      setIsEditingWinner(false);
      setWinnerLookupStatus(null);
    } catch (error) {
      console.error("Error guardando sorteo:", error);
      showNotification("Error al guardar el sorteo en la base de datos", "error");
    }
  };

  const handleEditWinner = (winner) => {
    if (!canEdit) return;
    setWinnerForm({
      id: winner.id,
      drawNumber: winner.drawNumber || '',
      prizeDescription: winner.prizeDescription || '',
      lottery: winner.lottery || '',
      drawDate: winner.drawDate || new Date().toISOString().split('T')[0],
      winningNumber: winner.winningNumber || '',
      sellerName: winner.sellerName || '',
      ticketInfo: winner.ticketInfo || '',
      createdAt: winner.createdAt
    });
    setIsEditingWinner(true);
    setWinnerLookupStatus(winner.winningNumber ? 'found' : null);
    setActiveTab('ganadores');
  };

  // Asignación rápida de Número Ganador en un sorteo programado
  const openQuickAssignWinner = (draw) => {
    if (!canEdit) return;
    const currentWinNum = draw.winningNumber || '';
    const match = currentWinNum ? findTicketByPlayedNumber(currentWinNum) : null;

    setQuickAssignModal({
      isOpen: true,
      draw,
      winningNumber: currentWinNum,
      sellerName: draw.sellerName || (match ? getTicketResponsable(match.ticket) : ''),
      ticketInfo: draw.ticketInfo || (match ? `Boleta #${getTicketBoleta(match.ticket)} (Paquete ${getTicketPaquete(match.ticket)} • ${match.matchedColumn})` : ''),
      lookupStatus: match ? 'found' : (currentWinNum ? 'not_found' : null)
    });
  };

  const handleQuickAssignNumberChange = (val) => {
    const cleanVal = val.trim().replace(/^#/, '');
    const match = findTicketByPlayedNumber(cleanVal);

    if (match) {
      setQuickAssignModal(prev => ({
        ...prev,
        winningNumber: val,
        sellerName: getTicketResponsable(match.ticket),
        ticketInfo: `Boleta #${getTicketBoleta(match.ticket)} (Paquete ${getTicketPaquete(match.ticket)} • ${match.matchedColumn})`,
        lookupStatus: 'found'
      }));
    } else {
      setQuickAssignModal(prev => ({
        ...prev,
        winningNumber: val,
        sellerName: '',
        ticketInfo: '',
        lookupStatus: cleanVal ? 'not_found' : null
      }));
    }
  };

  const handleSaveQuickAssign = async (e) => {
    e.preventDefault();
    if (!user || !canEdit || !quickAssignModal.draw) return;

    const d = quickAssignModal.draw;
    const cleanWinNum = String(quickAssignModal.winningNumber || '').trim().replace(/^#/, '');

    try {
      const winnerRef = doc(db, 'artifacts', appId, 'public', 'data', 'rifa_winners', d.id);
      await setDoc(winnerRef, {
        ...d,
        winningNumber: cleanWinNum,
        sellerName: quickAssignModal.sellerName.trim(),
        ticketInfo: quickAssignModal.ticketInfo || '',
        updatedAt: Date.now()
      });
      showNotification(`Número ganador #${cleanWinNum} asignado a ${d.drawNumber}`);
      setQuickAssignModal({ isOpen: false, draw: null, winningNumber: '', sellerName: '', ticketInfo: '', lookupStatus: null });
    } catch (error) {
      console.error("Error asignando ganador rápido:", error);
      showNotification("No se pudo actualizar el sorteo", "error");
    }
  };

  useEffect(() => {
    if (!isEditingWinner && !winnerForm.drawNumber) {
      setWinnerForm(prev => ({
        ...prev,
        drawNumber: `Sorteo #${winners.length + 1}`
      }));
    }
  }, [winners.length, isEditingWinner]);

  // --- ELIMINACIÓN DE REGISTROS ---
  const confirmDelete = async () => {
    if (!user || !canEdit || !deleteConfirm.id) return;
    try {
      const collectionName = deleteConfirm.type === 'ticket' ? 'rifa_tickets' : 'rifa_winners';
      await deleteDoc(doc(db, 'artifacts', appId, 'public', 'data', collectionName, deleteConfirm.id));
      showNotification("Registro eliminado correctamente");
    } catch (error) {
      console.error("Error eliminando:", error);
      showNotification("No se pudo eliminar el registro", "error");
    } finally {
      setDeleteConfirm({ isOpen: false, type: '', id: '', label: '' });
    }
  };

  // --- UTILIDAD PARA COPIAR RESUMEN AL PORTAPAPELES ---
  const copyToClipboard = (text, successMsg) => {
    const textArea = document.createElement("textarea");
    textArea.value = text;
    document.body.appendChild(textArea);
    textArea.select();
    try {
      document.execCommand('copy');
      showNotification(successMsg);
    } catch (err) {
      showNotification("No se pudo copiar el texto", "error");
    }
    document.body.removeChild(textArea);
  };

  const handleCopyWinnersSummary = () => {
    if (winners.length === 0) {
      showNotification("Aún no hay premios sorteados para copiar", "error");
      return;
    }
    const lines = winners.map(w => 
      `🏆 ${w.drawNumber} | Premio: ${w.prizeDescription || '—'} | Lotería: ${w.lottery || '—'} | Fecha: ${w.drawDate || '—'} | N° Ganador: ${w.winningNumber ? `#${w.winningNumber}` : 'Pendiente'} | Vendido por: ${w.sellerName || '—'}${w.ticketInfo ? ` (${w.ticketInfo})` : ''}`
    );
    const fullText = `=== LISTA DE PREMIOS SORTEADOS Y GANADORES ===\n${lines.join('\n')}`;
    copyToClipboard(fullText, "Resumen de premios sorteados copiado al portapapeles");
  };

  const handleCopyTicketsCSV = () => {
    if (tickets.length === 0) {
      showNotification("No hay boletas registradas para exportar", "error");
      return;
    }
    const header = "Paquete,Boleta,Numero 1,Numero 2,Numero 3,Numero 4,Responsable";
    const rows = tickets.map(t => {
      const [n1, n2, n3, n4] = getTicketNumbers(t);
      return `${getTicketPaquete(t)},${getTicketBoleta(t)},${n1},${n2},${n3},${n4},${getTicketResponsable(t)}`;
    });
    copyToClipboard([header, ...rows].join('\n'), "Base de datos copiada en formato CSV (7 columnas)");
  };

  return (
    <div className="min-h-screen bg-[#fbf5ea] text-slate-800 font-sans pb-16">
      {/* AMBIENTE NAVIDEÑO: nieve y trineo interactivo */}
      <Snowfall />
      <InteractiveSleigh />

      {/* NOTIFICACIÓN FLOTANTE (TOAST) */}
      {toast && (
        <div className="fixed bottom-5 right-5 z-50 flex items-center gap-3 px-4 py-3 rounded-xl shadow-lg border transition-all duration-300 bg-slate-900 text-white border-slate-700">
          {toast.type === 'error' ? (
            <AlertCircle className="w-5 h-5 text-rose-400 shrink-0" />
          ) : (
            <CheckCircle2 className="w-5 h-5 text-amber-400 shrink-0" />
          )}
          <span className="text-sm font-medium">{toast.message}</span>
        </div>
      )}

      {/* BARRA SUPERIOR DE ESTADO DE ROL Y ACCESO */}
      <div className={`w-full py-2 px-4 text-xs font-semibold transition-colors ${
        canEdit 
          ? 'bg-[#3b0710] text-amber-200 border-b border-amber-700' 
          : 'bg-[#2a050b] text-rose-100 border-b border-red-950'
      }`}>
        <div className="max-w-6xl mx-auto flex flex-wrap items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            {canEdit ? (
              <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/30 font-bold">
                <ShieldCheck className="w-3.5 h-3.5 text-amber-400" />
                Modo Administrador Activo (Edición Habilitada)
              </span>
            ) : (
              <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-rose-500/20 text-rose-300 border border-rose-500/30 font-bold">
                <Eye className="w-3.5 h-3.5 text-rose-400" />
                Modo Consulta (Solo Lectura)
              </span>
            )}
            <span className="hidden sm:inline text-slate-400">
              {canEdit 
                ? 'Tienes control total para asignar números, importar lotes y publicar ganadores.' 
                : 'Puedes consultar cualquier número y ver el historial de ganadores en tiempo real.'}
            </span>
          </div>

          <div className="flex items-center gap-2 ml-auto">
            {/* Botón de Compartir App */}
            <button
              onClick={() => setIsShareModalOpen(true)}
              className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-white/10 hover:bg-white/15 text-white transition cursor-pointer"
            >
              <Share2 className="w-3.5 h-3.5 text-rose-400" />
              <span>Compartir App (Modo Consulta)</span>
            </button>

            {/* Controles de Administrador / Vista Previa Invitado */}
            {isAdminUnlocked ? (
              <div className="flex items-center gap-1.5">
                <button
                  onClick={() => {
                    setPreviewAsGuest(!previewAsGuest);
                    showNotification(
                      !previewAsGuest 
                        ? "Vista previa como invitado activada (Solo lectura)" 
                        : "De vuelta al Modo Administrador con edición"
                    );
                  }}
                  className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg border transition cursor-pointer ${
                    previewAsGuest
                      ? 'bg-amber-400 text-slate-950 border-amber-300 font-bold'
                      : 'bg-white/10 hover:bg-white/15 text-white border-white/15'
                  }`}
                  title="Comprobar cómo ven la aplicación los usuarios invitados"
                >
                  {previewAsGuest ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                  <span>{previewAsGuest ? 'Salir de Vista Invitado' : 'Vista Previa Invitado'}</span>
                </button>

                {!previewAsGuest && (
                  <button
                    onClick={handleOpenSettings}
                    className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-white/10 hover:bg-white/15 text-white transition cursor-pointer"
                    title="Configurar PIN de Administrador y Privacidad"
                  >
                    <Settings className="w-3.5 h-3.5 text-amber-300" />
                    <span className="hidden md:inline">Ajustes Admin</span>
                  </button>
                )}

                <button
                  onClick={() => {
                    clearAdminSession();
                    setIsAdminUnlocked(false);
                    setPreviewAsGuest(false);
                    showNotification("Sesión de administrador cerrada. Modo Consulta activo.");
                  }}
                  className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-rose-500/20 hover:bg-rose-500/30 text-rose-200 border border-rose-500/30 transition cursor-pointer"
                >
                  <Lock className="w-3.5 h-3.5" />
                  <span>Bloquear</span>
                </button>
              </div>
            ) : (
              <button
                onClick={() => setIsPinModalOpen(true)}
                className="inline-flex items-center gap-1.5 px-3 py-1 rounded-lg bg-red-600 hover:bg-red-500 text-white font-bold shadow-2xs transition cursor-pointer"
              >
                <KeyRound className="w-3.5 h-3.5 text-amber-300" />
                <span>Acceso Administrador</span>
              </button>
            )}
          </div>
        </div>
      </div>

      {/* ENCABEZADO SUPERIOR Y ESTADÍSTICAS */}
      <header className="bg-gradient-to-r from-[#5c0a14] via-red-800 to-[#5c0a14] text-white shadow-md">
        <ChristmasLights />
        <div className="max-w-6xl mx-auto px-4 sm:px-6 py-6">
          <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
            <div className="flex items-center gap-3">
              <div className="p-3 bg-white/10 backdrop-blur-md rounded-2xl border border-white/20 shadow-inner">
                <span className="text-3xl leading-none" aria-hidden="true">🎅</span>
              </div>
              <div>
                <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight">
                  {appConfig.raffleTitle || 'Control de Rifas y Sorteos'}
                </h1>
                <p className="text-red-200 text-sm">
                  Consulta instantánea de números asignados e historial de ganadores en tiempo real
                </p>
              </div>
            </div>

            {canEdit && (
              <div className="flex flex-wrap items-center gap-2">
                <button
                  onClick={() => openNewTicketModal('')}
                  className="flex items-center gap-2 bg-amber-400 hover:bg-amber-300 text-slate-900 font-bold px-4 py-2.5 rounded-xl shadow-sm transition transform active:scale-95 text-sm cursor-pointer"
                >
                  <Plus className="w-4 h-4 stroke-[2.5]" />
                  Nueva Boleta
                </button>
                <button
                  onClick={() => setIsBulkModalOpen(true)}
                  className="flex items-center gap-2 bg-white/10 hover:bg-white/20 text-white font-medium px-3.5 py-2.5 rounded-xl border border-white/15 transition text-sm cursor-pointer"
                >
                  <Upload className="w-4 h-4" />
                  Importar Base de Boletas
                </button>
                <button
                  onClick={() => setIsBulkWinnerModalOpen(true)}
                  className="flex items-center gap-2 bg-amber-500/20 hover:bg-amber-500/30 text-amber-200 font-semibold px-3.5 py-2.5 rounded-xl border border-amber-400/30 transition text-sm cursor-pointer"
                >
                  <Trophy className="w-4 h-4 text-amber-300" />
                  Importar Premios Sorteados
                </button>
              </div>
            )}
          </div>

          {/* TARJETAS DE ESTADÍSTICAS RÁPIDAS */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mt-6">
            <div className="bg-white/10 backdrop-blur-sm border border-white/15 rounded-xl p-3.5">
              <div className="text-red-200 text-xs font-medium uppercase tracking-wider">Total Boletas</div>
              <div className="text-2xl sm:text-3xl font-black mt-1 flex items-baseline gap-2">
                {stats.totalBoletas}
                <span className="text-xs font-normal text-red-200">registradas</span>
              </div>
            </div>

            <div className="bg-white/10 backdrop-blur-sm border border-white/15 rounded-xl p-3.5">
              <div className="text-amber-200 text-xs font-medium uppercase tracking-wider">Números en Juego</div>
              <div className="text-2xl sm:text-3xl font-black mt-1 text-amber-300 flex items-baseline gap-2">
                {stats.totalNumbersAssigned}
                <span className="text-xs font-normal text-red-200">(4 por boleta)</span>
              </div>
            </div>

            <div className="bg-white/10 backdrop-blur-sm border border-white/15 rounded-xl p-3.5">
              <div className="text-amber-200 text-xs font-medium uppercase tracking-wider">Responsables / Paquetes</div>
              <div className="text-2xl sm:text-3xl font-black mt-1 text-amber-300 flex items-baseline gap-2">
                {stats.uniqueResponsables.length}
                <span className="text-xs font-normal text-red-200">en {stats.uniquePaquetes.length} paq.</span>
              </div>
            </div>

            <div className="bg-white/10 backdrop-blur-sm border border-white/15 rounded-xl p-3.5">
              <div className="text-amber-200 text-xs font-medium uppercase tracking-wider">Sorteos / Ganadores</div>
              <div className="text-2xl sm:text-3xl font-black mt-1 text-amber-400 flex items-baseline gap-2">
                {stats.totalWinners}
                <span className="text-xs font-normal text-red-200">registrados</span>
              </div>
            </div>
          </div>
        </div>
      </header>

      <ChristmasBanner />

      {/* BANNER AVISO SI ESTÁ EN VISTA PREVIA COMO INVITADO */}
      {isAdminUnlocked && previewAsGuest && (
        <div className="bg-amber-100 border-b border-amber-300 px-4 py-2.5 text-amber-950 text-xs sm:text-sm">
          <div className="max-w-6xl mx-auto flex items-center justify-between gap-4">
            <div className="flex items-center gap-2">
              <Eye className="w-4 h-4 text-amber-700 shrink-0" />
              <span>
                <strong>Vista Previa como Invitado activa:</strong> Así es exactamente como ven la app las personas con quienes compartes el enlace (sin botones de edición).
              </span>
            </div>
            <button
              onClick={() => setPreviewAsGuest(false)}
              className="px-3 py-1 rounded-lg bg-amber-900 text-white font-bold text-xs shrink-0 hover:bg-amber-800 transition cursor-pointer"
            >
              Volver a Edición Admin
            </button>
          </div>
        </div>
      )}

      {/* BARRA DE NAVEGACIÓN DE SECCIONES */}
      <div className="bg-white border-b border-slate-200 sticky top-0 z-30 shadow-xs">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 flex overflow-x-auto no-scrollbar gap-2 py-2.5">
          <button
            onClick={() => setActiveTab('buscador')}
            className={`flex items-center gap-2 px-4 py-2.5 rounded-xl font-semibold text-sm whitespace-nowrap transition ${
              activeTab === 'buscador'
                ? 'bg-red-600 text-white shadow-xs'
                : 'text-slate-600 hover:bg-slate-100'
            }`}
          >
            <Search className="w-4 h-4" />
            1. Buscador de Números
          </button>

          <button
            onClick={() => setActiveTab('ganadores')}
            className={`flex items-center gap-2 px-4 py-2.5 rounded-xl font-semibold text-sm whitespace-nowrap transition ${
              activeTab === 'ganadores'
                ? 'bg-red-600 text-white shadow-xs'
                : 'text-slate-600 hover:bg-slate-100'
            }`}
          >
            <Trophy className="w-4 h-4" />
            2. Premios Sorteados y Ganadores
            {winners.length > 0 && (
              <span className={`px-2 py-0.5 text-xs rounded-full ${
                activeTab === 'ganadores' ? 'bg-red-800 text-amber-300' : 'bg-amber-100 text-amber-800'
              }`}>
                {winners.length}
              </span>
            )}
          </button>

          <button
            onClick={() => setActiveTab('directorio')}
            className={`flex items-center gap-2 px-4 py-2.5 rounded-xl font-semibold text-sm whitespace-nowrap transition ${
              activeTab === 'directorio'
                ? 'bg-red-600 text-white shadow-xs'
                : 'text-slate-600 hover:bg-slate-100'
            }`}
          >
            <Ticket className="w-4 h-4" />
            3. Base de Datos Completa ({tickets.length})
          </button>

          <button
            onClick={() => setActiveTab('dashboard')}
            className={`flex items-center gap-2 px-4 py-2.5 rounded-xl font-semibold text-sm whitespace-nowrap transition ${
              activeTab === 'dashboard'
                ? 'bg-red-600 text-white shadow-xs'
                : 'text-slate-600 hover:bg-slate-100'
            }`}
          >
            <BarChart3 className="w-4 h-4" />
            4. Dashboard y Ranking
            {dashboardMetrics.rankingList.length > 0 && (
              <span className={`px-2 py-0.5 text-xs rounded-full ${
                activeTab === 'dashboard' ? 'bg-red-800 text-amber-300' : 'bg-amber-100 text-amber-800'
              }`}>
                Top {Math.min(3, dashboardMetrics.rankingList.length)}
              </span>
            )}
          </button>
        </div>
      </div>

      {/* CONTENIDO PRINCIPAL */}
      <main className="max-w-6xl mx-auto px-4 sm:px-6 py-8">
        {loading ? (
          <div className="bg-white rounded-2xl p-12 text-center shadow-xs border border-slate-200">
            <RefreshCw className="w-8 h-8 text-red-600 animate-spin mx-auto mb-3" />
            <p className="text-slate-600 font-medium">Sincronizando base de datos de la rifa...</p>
          </div>
        ) : (
          <>
            {/* ==========================================
                PESTAÑA 1: BUSCADOR DE NÚMEROS E INFORMACIÓN
               ========================================== */}
            {activeTab === 'buscador' && (
              <div className="space-y-8">
                {/* Caja Principal de Búsqueda */}
                <div className="bg-white rounded-2xl shadow-sm border border-slate-200 p-6 sm:p-8">
                  <div className="max-w-2xl mx-auto text-center">
                    <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wider bg-red-50 text-red-700 mb-3">
                      <Sparkles className="w-3.5 h-3.5" /> Buscador en los 4 Números de cada Boleta
                    </span>
                    <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900">
                      ¿Qué número deseas consultar?
                    </h2>
                    <p className="text-slate-500 mt-1 text-sm sm:text-base">
                      Digita cualquier número para buscarlo automáticamente en <strong>Numero 1, Numero 2, Numero 3 y Numero 4</strong> e identificar su <strong>Boleta, Paquete y Responsable</strong>.
                    </p>

                    <div className="mt-6 relative max-w-md mx-auto">
                      <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
                        <Search className="h-6 w-6 text-red-500" />
                      </div>
                      <input
                        type="text"
                        value={searchNumber}
                        onChange={(e) => setSearchNumber(e.target.value)}
                        placeholder="Ej. 0124, 5389, 7624..."
                        className="block w-full pl-12 pr-12 py-4 text-2xl font-bold text-center tracking-wider bg-slate-50 border-2 border-red-200 rounded-2xl focus:ring-4 focus:ring-red-500/20 focus:border-red-600 focus:bg-white transition outline-none text-slate-900 placeholder:text-slate-300 placeholder:font-normal placeholder:text-lg"
                      />
                      {searchNumber && (
                        <button
                          onClick={() => setSearchNumber('')}
                          className="absolute inset-y-0 right-0 pr-4 flex items-center text-slate-400 hover:text-slate-600 cursor-pointer"
                        >
                          <X className="h-6 w-6" />
                        </button>
                      )}
                    </div>
                  </div>

                  {/* Resultado de la Búsqueda */}
                  <div className="mt-8 max-w-3xl mx-auto">
                    {!searchNumber.trim() ? (
                      <div className="text-center py-6 bg-slate-50 rounded-xl border border-dashed border-slate-200">
                        <Ticket className="w-10 h-10 text-slate-300 mx-auto mb-2" />
                        <p className="text-sm text-slate-500">
                          Escribe un número arriba para conocer de inmediato su Paquete, Boleta, los 4 números asociados y el Responsable asignado.
                        </p>
                        {tickets.length === 0 && canEdit && (
                          <div className="mt-4">
                            <button
                              onClick={handleLoadSampleData}
                              className="inline-flex items-center gap-2 text-xs font-semibold text-red-600 bg-red-50 hover:bg-red-100 px-3.5 py-2 rounded-lg transition cursor-pointer"
                            >
                              <Sparkles className="w-4 h-4" />
                              ¿Base de datos vacía? Cargar 6 boletas de ejemplo (con 4 números c/u)
                            </button>
                          </div>
                        )}
                      </div>
                    ) : searchResult ? (
                      /* TARJETA DE BOLETA Y NÚMERO ENCONTRADO */
                      (() => {
                        const t = searchResult.ticket;
                        const nums = getTicketNumbers(t);
                        const resp = getTicketResponsable(t);
                        const bol = getTicketBoleta(t);
                        const paq = getTicketPaquete(t);

                        return (
                          <div className="bg-gradient-to-br from-red-50/80 via-white to-red-50/40 rounded-2xl border-2 border-red-500/30 p-6 shadow-md transition-all">
                            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-5 border-b border-slate-200">
                              <div className="flex items-center gap-4">
                                <div className="w-16 h-16 rounded-2xl bg-red-600 text-white flex flex-col items-center justify-center shadow-md shrink-0">
                                  <span className="text-[10px] uppercase tracking-widest opacity-80 font-semibold">Boleta</span>
                                  <span className="text-2xl font-black leading-none">#{bol}</span>
                                </div>
                                <div>
                                  <div className="flex items-center gap-2 flex-wrap">
                                    <span className="px-2.5 py-0.5 rounded-md text-xs font-bold uppercase bg-red-100 text-red-800">
                                      Paquete {paq}
                                    </span>
                                    <span className="px-2.5 py-0.5 rounded-md text-xs font-bold bg-amber-100 text-amber-800 border border-amber-200">
                                      Encontrado en {searchResult.matchedColumn}
                                    </span>
                                  </div>
                                  <div className="text-xs uppercase font-bold text-slate-400 mt-2">
                                    Responsable Asignado:
                                  </div>
                                  <h3 className="text-xl sm:text-2xl font-extrabold text-slate-900 flex items-center gap-2">
                                    <UserCheck className="w-5 h-5 text-amber-600 shrink-0" />
                                    {resp}
                                  </h3>
                                </div>
                              </div>

                              {canEdit && (
                                <div className="flex flex-wrap items-center gap-2 self-start sm:self-center">
                                  <button
                                    onClick={() => openEditTicketModal(t)}
                                    className="flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-semibold bg-slate-100 hover:bg-slate-200 text-slate-700 transition cursor-pointer"
                                  >
                                    <Edit3 className="w-4 h-4" /> Editar Boleta
                                  </button>
                                  <button
                                    onClick={() => {
                                      const numToWin = searchResult.matchType === 'numero' ? searchResult.matchedValue : (nums[0] || '');
                                      setWinnerForm(prev => ({
                                        ...prev,
                                        winningNumber: numToWin,
                                        sellerName: resp,
                                        ticketInfo: `Boleta #${bol} (Paquete ${paq} • ${searchResult.matchedColumn})`
                                      }));
                                      setWinnerLookupStatus('found');
                                      setActiveTab('ganadores');
                                    }}
                                    className="flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-semibold bg-amber-400 hover:bg-amber-300 text-slate-900 transition shadow-xs cursor-pointer"
                                  >
                                    <Trophy className="w-4 h-4" /> Declarar Ganador
                                  </button>
                                </div>
                              )}
                            </div>

                            {/* Visualización de las 7 Columnas de la Boleta (con los 4 Números resaltados) */}
                            <div className="mt-5">
                              <div className="text-xs font-bold uppercase text-slate-500 mb-2.5">
                                Números asignados a esta Boleta (Paquete {paq} • Boleta #{bol}):
                              </div>
                              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                                {nums.map((numVal, idx) => {
                                  const isMatched =
                                    searchResult.matchType === 'numero' &&
                                    String(numVal).toLowerCase() === String(searchNumber.trim().replace(/^#/, '')).toLowerCase();
                                  return (
                                    <div
                                      key={idx}
                                      className={`p-3.5 rounded-xl border text-center transition ${
                                        isMatched
                                          ? 'bg-amber-400/20 border-2 border-amber-500 shadow-xs ring-2 ring-amber-400/30'
                                          : 'bg-white border-slate-200'
                                      }`}
                                    >
                                      <div className="text-[11px] font-bold uppercase text-slate-500">
                                        Numero {idx + 1}
                                      </div>
                                      <div className={`text-xl font-black mt-1 tracking-wider ${
                                        isMatched ? 'text-amber-950' : 'text-slate-900'
                                      }`}>
                                        {numVal || '—'}
                                      </div>
                                      {isMatched && (
                                        <span className="inline-block mt-1 px-2 py-0.5 text-[10px] font-extrabold uppercase bg-amber-400 text-slate-950 rounded-full">
                                          Número Consultado
                                        </span>
                                      )}
                                    </div>
                                  );
                                })}
                              </div>
                            </div>

                            {searchedTicketWinnerInfo && (
                              <div className="mt-4 bg-amber-50 border border-amber-300 rounded-xl p-3.5 flex items-center gap-3 text-amber-900">
                                <Trophy className="w-6 h-6 text-amber-600 shrink-0" />
                                <div className="text-sm">
                                  <strong>¡Esta boleta tiene un número ganador!</strong> El número{' '}
                                  <span className="font-black">#{searchedTicketWinnerInfo.winningNumber}</span> ganó en el{' '}
                                  <span className="underline font-bold">{searchedTicketWinnerInfo.drawNumber}</span>
                                  {searchedTicketWinnerInfo.prizeDescription && (
                                    <span> — Premio: <strong>{searchedTicketWinnerInfo.prizeDescription}</strong></span>
                                  )}
                                  {searchedTicketWinnerInfo.lottery && (
                                    <span> ({searchedTicketWinnerInfo.lottery})</span>
                                  )}
                                </div>
                              </div>
                            )}
                          </div>
                        );
                      })()
                    ) : (
                      /* TARJETA DE NÚMERO DISPONIBLE / NO REGISTRADO */
                      <div className="bg-amber-50/70 rounded-2xl border-2 border-dashed border-amber-300 p-6 text-center">
                        <div className="w-14 h-14 rounded-2xl bg-amber-100 text-amber-700 flex items-center justify-center mx-auto mb-3 font-black text-xl">
                          #{searchNumber.trim()}
                        </div>
                        <span className="inline-block px-3 py-1 rounded-full text-xs font-bold uppercase bg-amber-200 text-amber-900 mb-2">
                          No Encontrado en Base de Datos
                        </span>
                        <h3 className="text-lg font-bold text-slate-800">
                          El número #{searchNumber.trim()} no aparece en Numero 1, 2, 3 ni 4
                        </h3>
                        <p className="text-sm text-slate-600 mt-1 max-w-md mx-auto">
                          {canEdit
                            ? 'Puedes registrarlo ahora mismo en una nueva boleta con su Paquete y Responsable.'
                            : 'Este número no se encuentra registrado en ninguna boleta actualmente.'}
                        </p>
                        {canEdit && (
                          <button
                            onClick={() => openNewTicketModal(searchNumber.trim())}
                            className="mt-4 inline-flex items-center gap-2 bg-amber-600 hover:bg-amber-700 text-white font-bold px-5 py-2.5 rounded-xl shadow-xs transition cursor-pointer"
                          >
                            <Plus className="w-4 h-4" />
                            Crear Boleta con el Número #{searchNumber.trim()}
                          </button>
                        )}
                      </div>
                    )}
                  </div>
                </div>

                {/* Acceso Rápido: Últimos Ganadores y Boletas Recientes */}
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                  {/* Resumen de Ganadores Recientes */}
                  <div className="bg-white rounded-2xl shadow-xs border border-slate-200 p-6">
                    <div className="flex items-center justify-between mb-4">
                      <div className="flex items-center gap-2.5">
                        <div className="p-2 bg-amber-100 text-amber-700 rounded-xl">
                          <Trophy className="w-5 h-5" />
                        </div>
                        <h3 className="font-bold text-slate-900 text-lg">Últimos Premios Sorteados</h3>
                      </div>
                      <button
                        onClick={() => setActiveTab('ganadores')}
                        className="text-xs font-semibold text-red-600 hover:text-red-800 cursor-pointer"
                      >
                        Ver cuadro completo →
                      </button>
                    </div>

                    {winners.length === 0 ? (
                      <div className="text-center py-8 bg-slate-50 rounded-xl border border-dashed border-slate-200">
                        <Award className="w-8 h-8 text-slate-300 mx-auto mb-2" />
                        <p className="text-sm text-slate-500">Aún no se han registrado sorteos ganadores.</p>
                        {canEdit && (
                          <button
                            onClick={() => setActiveTab('ganadores')}
                            className="mt-3 text-xs font-bold text-red-600 hover:underline cursor-pointer"
                          >
                            + Registrar primer sorteo
                          </button>
                        )}
                      </div>
                    ) : (
                      <div className="space-y-3">
                        {winners.slice(0, 4).map((w) => (
                          <div
                            key={w.id}
                            className="flex items-center justify-between p-3.5 rounded-xl bg-slate-50 border border-slate-200/80 hover:border-amber-300 transition"
                          >
                            <div className="flex items-center gap-3">
                              <div className="px-3 py-1.5 bg-amber-400 text-slate-900 font-black rounded-lg text-sm">
                                {w.winningNumber ? `#${w.winningNumber}` : 'Pend.'}
                              </div>
                              <div>
                                <div className="text-xs font-bold uppercase text-red-600">
                                  {w.drawNumber} — {w.prizeDescription}
                                </div>
                                <div className="text-xs text-slate-600 mt-0.5">
                                  Vendido por (Responsable):{' '}
                                  <span className="font-bold text-slate-900">{w.sellerName || 'Por definir'}</span>
                                </div>
                              </div>
                            </div>
                            {w.winningNumber && (
                              <button
                                onClick={() => setSearchNumber(String(w.winningNumber))}
                                className="text-xs text-red-600 hover:underline font-medium cursor-pointer"
                              >
                                Ver boleta
                              </button>
                            )}
                          </div>
                        ))}
                      </div>
                    )}
                  </div>

                  {/* Vista Rápida de Boletas Registradas */}
                  <div className="bg-white rounded-2xl shadow-xs border border-slate-200 p-6">
                    <div className="flex items-center justify-between mb-4">
                      <div className="flex items-center gap-2.5">
                        <div className="p-2 bg-red-100 text-red-700 rounded-xl">
                          <Ticket className="w-5 h-5" />
                        </div>
                        <h3 className="font-bold text-slate-900 text-lg">Muestra Rápida de Boletas</h3>
                      </div>
                      <button
                        onClick={() => setActiveTab('directorio')}
                        className="text-xs font-semibold text-red-600 hover:text-red-800 cursor-pointer"
                      >
                        Ver las {tickets.length} boletas →
                      </button>
                    </div>

                    {tickets.length === 0 ? (
                      <div className="text-center py-8 bg-slate-50 rounded-xl border border-dashed border-slate-200">
                        <p className="text-sm text-slate-500">No hay boletas cargadas todavía.</p>
                        {canEdit && (
                          <button
                            onClick={() => setIsBulkModalOpen(true)}
                            className="mt-3 text-xs font-bold text-red-600 hover:underline cursor-pointer"
                          >
                            + Importar boletas desde Excel
                          </button>
                        )}
                      </div>
                    ) : (
                      <div className="space-y-2 max-h-60 overflow-y-auto pr-1">
                        {tickets.slice(0, 8).map((t) => {
                          const nums = getTicketNumbers(t).filter(Boolean);
                          return (
                            <div
                              key={t.id}
                              className="flex flex-wrap items-center justify-between gap-2 p-2.5 rounded-xl bg-slate-50 border border-slate-200 text-xs"
                            >
                              <div>
                                <span className="font-bold text-slate-700">
                                  Paq. {getTicketPaquete(t)} • Boleta #{getTicketBoleta(t)}
                                </span>
                                <span className="text-slate-400 mx-1.5">|</span>
                                <span className="font-semibold text-amber-700">
                                  {getTicketResponsable(t)}
                                </span>
                              </div>
                              <div className="flex items-center gap-1">
                                {nums.map((n, i) => (
                                  <button
                                    key={i}
                                    onClick={() => setSearchNumber(String(n))}
                                    className="px-2 py-1 rounded bg-white border border-slate-300 hover:border-red-500 hover:text-red-600 font-mono font-bold transition cursor-pointer"
                                  >
                                    {n}
                                  </button>
                                ))}
                              </div>
                            </div>
                          );
                        })}
                      </div>
                    )}
                  </div>
                </div>
              </div>
            )}

            {/* ==========================================
                PESTAÑA 2: SECCIÓN DE PREMIOS SORTEADOS Y GANADORES
               ========================================== */}
            {activeTab === 'ganadores' && (
              <div className="space-y-6">
                {/* Barra superior de importación masiva de premios sorteados (Solo Admin) */}
                {canEdit && (
                  <div className="bg-rose-50 border border-rose-200 rounded-2xl p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                    <div className="flex items-center gap-3">
                      <div className="p-2.5 bg-[#b91c1c] text-white rounded-xl shrink-0 shadow-2xs">
                        <Trophy className="w-5 h-5" />
                      </div>
                      <div>
                        <h3 className="text-sm font-extrabold text-slate-900">
                          Importar Tabla de Premios Sorteados desde Excel
                        </h3>
                        <p className="text-xs text-slate-600">
                          Importa las columnas <strong>Numero de Sorteo, Premio, Lotería, Fecha del Sorteo y Vendido por:</strong> directamente copiando y pegando desde Excel.
                        </p>
                      </div>
                    </div>
                    <button
                      onClick={() => setIsBulkWinnerModalOpen(true)}
                      className="inline-flex items-center justify-center gap-2 bg-[#b91c1c] hover:bg-[#991b1b] text-white font-bold px-4 py-2.5 rounded-xl shadow-xs transition text-xs sm:text-sm shrink-0 cursor-pointer"
                    >
                      <Upload className="w-4 h-4" />
                      Importar Premios Sorteados
                    </button>
                  </div>
                )}

                <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
                  {/* Columna Izquierda: Formulario para Registrar Premio / Sorteo (SOLO ADMIN) */}
                  {canEdit && (
                    <div className="lg:col-span-4">
                      <div className="bg-white rounded-2xl shadow-sm border border-slate-200 p-5 sticky top-20">
                        <div className="flex items-center gap-3 mb-4 pb-3 border-b border-slate-100">
                          <div className="p-2 bg-[#b91c1c]/10 text-[#b91c1c] rounded-xl">
                            <Trophy className="w-5 h-5" />
                          </div>
                          <div>
                            <h2 className="text-base font-extrabold text-slate-900">
                              {isEditingWinner ? 'Editar Premio Sorteado' : 'Agregar Premio / Sorteo'}
                            </h2>
                            <p className="text-[11px] text-slate-500">
                              Registra el sorteo o ingresa el número ganador para buscar quién lo vendió.
                            </p>
                          </div>
                        </div>

                        <form onSubmit={handleSaveWinner} className="space-y-3.5">
                          <div className="grid grid-cols-2 gap-3">
                            <div>
                              <label className="block text-[11px] font-bold uppercase text-slate-600 mb-1">
                                Numero de Sorteo *
                              </label>
                              <input
                                type="text"
                                required
                                value={winnerForm.drawNumber}
                                onChange={(e) => setWinnerForm({ ...winnerForm, drawNumber: e.target.value })}
                                placeholder="Ej. Sorteo 1"
                                className="w-full px-3 py-2 rounded-xl border border-slate-300 focus:ring-2 focus:ring-[#b91c1c] outline-none text-sm font-semibold"
                              />
                            </div>

                            <div>
                              <label className="block text-[11px] font-bold uppercase text-slate-600 mb-1">
                                Lotería
                              </label>
                              <input
                                type="text"
                                value={winnerForm.lottery}
                                onChange={(e) => setWinnerForm({ ...winnerForm, lottery: e.target.value })}
                                placeholder="Ej. Boyacá / Medellín"
                                className="w-full px-3 py-2 rounded-xl border border-slate-300 focus:ring-2 focus:ring-[#b91c1c] outline-none text-sm"
                              />
                            </div>
                          </div>

                          <div>
                            <label className="block text-[11px] font-bold uppercase text-slate-600 mb-1">
                              Premio *
                            </label>
                            <input
                              type="text"
                              required
                              value={winnerForm.prizeDescription}
                              onChange={(e) => setWinnerForm({ ...winnerForm, prizeDescription: e.target.value })}
                              placeholder="Ej. Bono $1.000.000 / Moto Yamaha"
                              className="w-full px-3 py-2 rounded-xl border border-slate-300 focus:ring-2 focus:ring-[#b91c1c] outline-none text-sm font-medium"
                            />
                          </div>

                          <div className="grid grid-cols-2 gap-3">
                            <div>
                              <label className="block text-[11px] font-bold uppercase text-slate-600 mb-1">
                                Fecha del Sorteo
                              </label>
                              <input
                                type="text"
                                value={winnerForm.drawDate}
                                onChange={(e) => setWinnerForm({ ...winnerForm, drawDate: e.target.value })}
                                placeholder="DD/MM/AAAA o YYYY-MM-DD"
                                className="w-full px-3 py-2 rounded-xl border border-slate-300 focus:ring-2 focus:ring-[#b91c1c] outline-none text-sm"
                              />
                            </div>

                            <div>
                              <label className="block text-[11px] font-bold uppercase text-amber-700 mb-1">
                                N° Ganador (Opcional)
                              </label>
                              <input
                                type="text"
                                value={winnerForm.winningNumber}
                                onChange={(e) => handleWinningNumberChange(e.target.value)}
                                placeholder="Ej. 007"
                                className="w-full px-3 py-2 rounded-xl border-2 border-amber-400 bg-amber-50/40 focus:ring-2 focus:ring-amber-500 focus:bg-white outline-none text-sm font-black text-slate-900"
                              />
                            </div>
                          </div>

                          {/* Aviso de Autocompletado desde la Base de Datos */}
                          {winnerLookupStatus === 'found' && (
                            <div className="p-2.5 rounded-xl bg-amber-50 border border-amber-200 text-amber-900 text-xs flex items-center gap-2">
                              <CheckCircle2 className="w-4 h-4 text-amber-600 shrink-0" />
                              <span>
                                <strong>¡Número encontrado en Base de Datos!</strong> Se asignó <strong>Vendido por: {winnerForm.sellerName}</strong> {winnerForm.ticketInfo && `(${winnerForm.ticketInfo})`}.
                              </span>
                            </div>
                          )}

                          {winnerLookupStatus === 'not_found' && (
                            <div className="p-2.5 rounded-xl bg-amber-50 border border-amber-200 text-amber-900 text-xs flex items-center gap-2">
                              <HelpCircle className="w-4 h-4 text-amber-600 shrink-0" />
                              <span>
                                El número #{winnerForm.winningNumber} no figura en Numero 1, 2, 3 ni 4. Puedes escribir manualmente el Responsable.
                              </span>
                            </div>
                          )}

                          <div>
                            <label className="block text-[11px] font-bold uppercase text-slate-600 mb-1">
                              Vendido por: (Responsable — Se llena solo al poner N° Ganador)
                            </label>
                            <div className="relative">
                              <UserCheck className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
                              <input
                                type="text"
                                value={winnerForm.sellerName}
                                onChange={(e) => setWinnerForm({ ...winnerForm, sellerName: e.target.value })}
                                placeholder="Nombre del Responsable..."
                                className="w-full pl-9 pr-3 py-2 rounded-xl border border-slate-300 focus:ring-2 focus:ring-[#b91c1c] outline-none text-sm font-semibold"
                              />
                            </div>
                          </div>

                          <div className="pt-2 flex items-center gap-2">
                            <button
                              type="submit"
                              className="w-full flex items-center justify-center gap-2 bg-[#b91c1c] hover:bg-[#991b1b] text-white font-bold py-2.5 px-4 rounded-xl shadow-sm transition text-sm cursor-pointer"
                            >
                              <Trophy className="w-4 h-4" />
                              {isEditingWinner ? 'Guardar Cambios' : 'Guardar Premio / Sorteo'}
                            </button>

                            {isEditingWinner && (
                              <button
                                type="button"
                                onClick={() => {
                                  setIsEditingWinner(false);
                                  setWinnerLookupStatus(null);
                                  setWinnerForm({
                                    id: '',
                                    drawNumber: `Sorteo #${winners.length + 1}`,
                                    prizeDescription: '',
                                    lottery: '',
                                    drawDate: new Date().toISOString().split('T')[0],
                                    winningNumber: '',
                                    sellerName: '',
                                    ticketInfo: ''
                                  });
                                }}
                                className="px-3.5 py-2.5 rounded-xl border border-slate-300 text-slate-600 hover:bg-slate-100 text-xs font-semibold cursor-pointer"
                              >
                                Cancelar
                              </button>
                            )}
                          </div>
                        </form>
                      </div>
                    </div>
                  )}

                  {/* Columna Derecha (o Ancho Completo en Modo Consulta): Tabla con las Columnas Exactas de la Imagen */}
                  <div className={canEdit ? 'lg:col-span-8' : 'lg:col-span-12'}>
                    <div className="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden">
                      <div className="p-5 border-b border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                        <div>
                          <h2 className="text-xl font-extrabold text-slate-900">
                            Lista Oficial de Premios Sorteados
                          </h2>
                          <p className="text-xs text-slate-500 mt-0.5">
                             Cuadro de sorteos con Premio, Lotería, Fecha del Sorteo, Número Ganador y Vendido por:
                          </p>
                        </div>

                        <div className="flex items-center gap-2 self-start sm:self-center">
                          {winners.length > 0 && (
                            <button
                              onClick={handleCopyWinnersSummary}
                              className="inline-flex items-center gap-2 px-3.5 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold text-xs transition cursor-pointer"
                            >
                              <Copy className="w-4 h-4" />
                              Copiar Resumen
                            </button>
                          )}
                        </div>
                      </div>

                      {winners.length === 0 ? (
                        <div className="p-12 text-center">
                          <div className="w-16 h-16 bg-rose-50 text-[#b91c1c] rounded-2xl flex items-center justify-center mx-auto mb-3">
                            <Trophy className="w-8 h-8" />
                          </div>
                          <h3 className="text-base font-bold text-slate-800">
                            Aún no hay premios sorteados registrados
                          </h3>
                          <p className="text-sm text-slate-500 max-w-md mx-auto mt-1">
                            {canEdit 
                              ? 'Usa el botón "Importar Premios Sorteados" arriba o el formulario de la izquierda para cargar el plan de sorteos.' 
                              : 'La lista de premios sorteados y ganadores aparecerá aquí en tiempo real.'}
                          </p>
                        </div>
                      ) : (
                        <div className="w-full">
                          {/* TABLA CON EL ESTILO EXACTO DEL ENCABEZADO AZUL DE LA IMAGEN */}
                          <table className="w-full table-auto border-collapse text-[11px] sm:text-sm leading-tight">
                            <thead>
                              <tr className="bg-[#c8102e] text-white font-bold text-center">
                                <th className="py-2 px-1 sm:py-3 sm:px-2 break-words border border-slate-800/40">
                                  N° Sorteo
                                </th>
                                <th className="py-2 px-1 sm:py-3 sm:px-3 break-words border border-slate-800/40">
                                  Premio
                                </th>
                                <th className="py-2 px-1 sm:py-3 sm:px-2 break-words border border-slate-800/40">
                                  Lotería
                                </th>
                                <th className="py-2 px-1 sm:py-3 sm:px-2 break-words border border-slate-800/40">
                                  Fecha del Sorteo
                                </th>
                                <th className="py-2 px-1 sm:py-3 sm:px-2 break-words border border-slate-800/40 bg-[#9b0d23]">
                                  N° Ganador
                                </th>
                                <th className="py-2 px-1 sm:py-3 sm:px-3 break-words border border-slate-800/40">
                                  Vendido por:
                                </th>
                                {canEdit && (
                                  <th className="py-2 px-1 sm:py-3 sm:px-2 break-words border border-slate-800/40 text-center">
                                    Acciones
                                  </th>
                                )}
                              </tr>
                            </thead>
                            <tbody className="divide-y divide-slate-200">
                              {winners.map((w, idx) => (
                                <tr
                                  key={w.id}
                                  className={`${
                                    idx % 2 === 0 ? 'bg-white' : 'bg-slate-50/70'
                                  } hover:bg-rose-50/60 transition`}
                                >
                                  {/* 1. Numero de Sorteo */}
                                  <td className="py-2 px-1 sm:py-3 sm:px-2 break-words border border-slate-200 text-center font-bold text-slate-900">
                                    {w.drawNumber}
                                  </td>

                                  {/* 2. Premio */}
                                  <td className="py-2 px-1 sm:py-3 sm:px-3 break-words border border-slate-200 font-semibold text-slate-800 text-center">
                                    {w.prizeDescription || <span className="text-slate-400">—</span>}
                                  </td>

                                  {/* 3. Lotería */}
                                  <td className="py-2 px-1 sm:py-3 sm:px-2 break-words border border-slate-200 text-center text-slate-700">
                                    {w.lottery || <span className="text-slate-400">—</span>}
                                  </td>

                                  {/* 4. Fecha del Sorteo */}
                                  <td className="py-2 px-1 sm:py-3 sm:px-2 break-words border border-slate-200 text-center text-slate-700">
                                    {w.drawDate || <span className="text-slate-400">—</span>}
                                  </td>

                                  {/* N° Ganador (Con botón rápido para asignar número y buscar vendedor) */}
                                  <td className="py-2 px-1 sm:py-3 sm:px-2 break-words border border-slate-200 text-center">
                                    {w.winningNumber ? (
                                      <button
                                        onClick={() => {
                                          if (canEdit) {
                                            openQuickAssignWinner(w);
                                          } else {
                                            setSearchNumber(String(w.winningNumber));
                                            setActiveTab('buscador');
                                          }
                                        }}
                                        className="inline-flex items-center px-1.5 sm:px-3 py-1 rounded-lg bg-amber-400 hover:bg-amber-300 text-slate-950 font-black text-xs sm:text-sm shadow-2xs transition cursor-pointer"
                                        title={canEdit ? "Clic para cambiar número ganador" : "Clic para consultar esta boleta"}
                                      >
                                        #{w.winningNumber}
                                      </button>
                                    ) : canEdit ? (
                                      <button
                                        onClick={() => openQuickAssignWinner(w)}
                                        className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-rose-50 hover:bg-rose-100 text-[#b91c1c] border border-rose-200 font-bold text-xs transition cursor-pointer"
                                      >
                                        <Plus className="w-3.5 h-3.5" /> Poner N° Ganador
                                      </button>
                                    ) : (
                                      <span className="text-xs font-medium text-slate-400 italic">
                                        Por jugar
                                      </span>
                                    )}
                                  </td>

                                  {/* 5. Vendido por: */}
                                  <td className="py-2 px-1 sm:py-3 sm:px-3 break-words border border-slate-200 text-center">
                                    {w.sellerName ? (
                                      <div>
                                        <span className="inline-flex items-center gap-1 px-1.5 sm:px-2.5 py-1 rounded-md bg-amber-50 break-words text-amber-900 border border-amber-200 font-bold text-xs">
                                          <UserCheck className="hidden sm:block w-3.5 h-3.5 text-amber-600 shrink-0" />
                                          {w.sellerName}
                                        </span>
                                        {w.ticketInfo && (
                                          <div className="text-[11px] text-slate-500 mt-1">
                                            {w.ticketInfo}
                                          </div>
                                        )}
                                      </div>
                                    ) : (
                                      <span className="text-xs text-slate-400">—</span>
                                    )}
                                  </td>

                                  {/* Acciones (Solo Admin) */}
                                  {canEdit && (
                                    <td className="py-2 px-1 sm:py-3 sm:px-2 break-words border border-slate-200 text-center">
                                      <div className="inline-flex flex-col sm:flex-row items-center gap-1">
                                        <button
                                          onClick={() => handleEditWinner(w)}
                                          className="p-1.5 text-slate-500 hover:text-[#b91c1c] hover:bg-rose-50 rounded-lg transition cursor-pointer"
                                          title="Editar fila"
                                        >
                                          <Edit3 className="w-4 h-4" />
                                        </button>
                                        <button
                                          onClick={() =>
                                            setDeleteConfirm({
                                              isOpen: true,
                                              type: 'winner',
                                              id: w.id,
                                              label: `Sorteo ${w.drawNumber} (${w.prizeDescription || ''})`
                                            })
                                          }
                                          className="p-1.5 text-slate-500 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition cursor-pointer"
                                          title="Eliminar fila"
                                        >
                                          <Trash2 className="w-4 h-4" />
                                        </button>
                                      </div>
                                    </td>
                                  )}
                                </tr>
                              ))}
                            </tbody>
                          </table>
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* ==========================================
                PESTAÑA 3: DIRECTORIO / BASE DE DATOS DE BOLETAS (7 COLUMNAS EXACTAS)
               ========================================== */}
            {activeTab === 'directorio' && (
              <div className="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden">
                {/* Barra de Herramientas y Filtros */}
                <div className="p-6 border-b border-slate-200 space-y-4">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                    <div>
                      <h2 className="text-xl font-extrabold text-slate-900">
                        Base de Datos de Boletas
                      </h2>
                      <p className="text-xs text-slate-500">
                        Estructura oficial: <strong>Paquete, Boleta, Numero 1, Numero 2, Numero 3, Numero 4 y Responsable</strong>
                      </p>
                    </div>

                    {canEdit && (
                      <div className="flex flex-wrap items-center gap-2">
                        <button
                          onClick={handleCopyTicketsCSV}
                          className="inline-flex items-center gap-1.5 px-3 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold text-xs transition cursor-pointer"
                        >
                          <Download className="w-4 h-4" /> Exportar CSV
                        </button>
                        <button
                          onClick={() => setIsBulkModalOpen(true)}
                          className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-red-50 hover:bg-red-100 text-red-700 font-bold text-xs transition cursor-pointer"
                        >
                          <Upload className="w-4 h-4" /> Importar desde Excel (7 Columnas)
                        </button>
                        <button
                          onClick={() => openNewTicketModal('')}
                          className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-red-600 hover:bg-red-700 text-white font-bold text-xs transition shadow-xs cursor-pointer"
                        >
                          <Plus className="w-4 h-4" /> Nueva Boleta
                        </button>
                      </div>
                    )}
                  </div>

                  {/* Controles de Búsqueda y Filtro */}
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-2">
                    <div className="relative">
                      <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
                      <input
                        type="text"
                        value={directorySearch}
                        onChange={(e) => setDirectorySearch(e.target.value)}
                        placeholder="Buscar en Numero 1..4, Boleta, Paquete o Responsable..."
                        className="w-full pl-9 pr-3 py-2 rounded-xl border border-slate-300 text-sm focus:ring-2 focus:ring-red-500 outline-none"
                      />
                    </div>

                    <div className="flex items-center gap-2">
                      <Filter className="w-4 h-4 text-slate-400 shrink-0" />
                      <select
                        value={filterPaquete}
                        onChange={(e) => setFilterPaquete(e.target.value)}
                        className="w-full px-3 py-2 rounded-xl border border-slate-300 text-sm bg-white focus:ring-2 focus:ring-red-500 outline-none"
                      >
                        <option value="Todos">Todos los Paquetes ({stats.uniquePaquetes.length})</option>
                        {stats.uniquePaquetes.map((paq) => (
                          <option key={paq} value={paq}>
                            Paquete: {paq}
                          </option>
                        ))}
                      </select>
                    </div>

                    <div>
                      <select
                        value={filterResponsable}
                        onChange={(e) => setFilterResponsable(e.target.value)}
                        className="w-full px-3 py-2 rounded-xl border border-slate-300 text-sm bg-white focus:ring-2 focus:ring-red-500 outline-none"
                      >
                        <option value="Todos">Todos los Responsables ({stats.uniqueResponsables.length})</option>
                        {stats.uniqueResponsables.map((resp) => (
                          <option key={resp} value={resp}>
                            Responsable: {resp}
                          </option>
                        ))}
                      </select>
                    </div>
                  </div>
                </div>

                {/* Tabla de Boletas con el Diseño Exacto de Encabezado de la Imagen */}
                {filteredTickets.length === 0 ? (
                  <div className="p-12 text-center">
                    <Ticket className="w-12 h-12 text-slate-300 mx-auto mb-3" />
                    <h3 className="text-base font-bold text-slate-800">
                      No se encontraron boletas con estos filtros
                    </h3>
                    <p className="text-sm text-slate-500 mt-1">
                      Intenta cambiar los términos de búsqueda o importa tu tabla desde Excel.
                    </p>
                  </div>
                ) : (
                  <div className="overflow-x-auto">
                    <table className="w-full border-collapse text-sm">
                      <thead>
                        <tr className="bg-white border-y-2 border-slate-800 text-slate-950 font-bold text-center select-none">
                          {['Paquete', 'Boleta', 'Numero 1', 'Numero 2', 'Numero 3', 'Numero 4', 'Responsable'].map((colName) => (
                            <th
                              key={colName}
                              className="py-2.5 px-3 border-x border-slate-400 whitespace-nowrap"
                            >
                              <div className="flex items-center justify-between gap-2">
                                <span className="mx-auto">{colName}</span>
                                <span className="inline-flex items-center justify-center w-4 h-4 bg-slate-100 border border-slate-300 rounded-xs text-[9px] text-slate-500 shrink-0">
                                  ▼
                                </span>
                              </div>
                            </th>
                          ))}
                          {canEdit && (
                            <th className="py-2.5 px-3 border-x border-slate-400 text-center whitespace-nowrap">
                              Acciones
                            </th>
                          )}
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-200">
                        {filteredTickets.map((t, index) => {
                          const [n1, n2, n3, n4] = getTicketNumbers(t);
                          return (
                            <tr
                              key={t.id}
                              className={`${
                                index % 2 === 0 ? 'bg-white' : 'bg-slate-50/70'
                              } hover:bg-red-50/50 transition text-center`}
                            >
                              <td className="py-2.5 px-3 border border-slate-200 font-semibold text-slate-700">
                                {getTicketPaquete(t)}
                              </td>
                              <td className="py-2.5 px-3 border border-slate-200 font-black text-red-900 bg-red-50/30">
                                {getTicketBoleta(t)}
                              </td>
                              <td
                                onClick={() => {
                                  if (n1) {
                                    setSearchNumber(n1);
                                    setActiveTab('buscador');
                                  }
                                }}
                                className="py-2.5 px-3 border border-slate-200 font-mono font-bold text-slate-900 hover:bg-amber-100 cursor-pointer transition"
                                title="Clic para inspeccionar este número"
                              >
                                {n1 || '—'}
                              </td>
                              <td
                                onClick={() => {
                                  if (n2) {
                                    setSearchNumber(n2);
                                    setActiveTab('buscador');
                                  }
                                }}
                                className="py-2.5 px-3 border border-slate-200 font-mono font-bold text-slate-900 hover:bg-amber-100 cursor-pointer transition"
                                title="Clic para inspeccionar este número"
                              >
                                {n2 || '—'}
                              </td>
                              <td
                                onClick={() => {
                                  if (n3) {
                                    setSearchNumber(n3);
                                    setActiveTab('buscador');
                                  }
                                }}
                                className="py-2.5 px-3 border border-slate-200 font-mono font-bold text-slate-900 hover:bg-amber-100 cursor-pointer transition"
                                title="Clic para inspeccionar este número"
                              >
                                {n3 || '—'}
                              </td>
                              <td
                                onClick={() => {
                                  if (n4) {
                                    setSearchNumber(n4);
                                    setActiveTab('buscador');
                                  }
                                }}
                                className="py-2.5 px-3 border border-slate-200 font-mono font-bold text-slate-900 hover:bg-amber-100 cursor-pointer transition"
                                title="Clic para inspeccionar este número"
                              >
                                {n4 || '—'}
                              </td>
                              <td className="py-2.5 px-4 border border-slate-200 font-bold text-slate-800 text-left sm:text-center">
                                {getTicketResponsable(t)}
                              </td>
                              {canEdit && (
                                <td className="py-2.5 px-3 border border-slate-200 whitespace-nowrap">
                                  <div className="inline-flex items-center gap-1">
                                    <button
                                      onClick={() => openEditTicketModal(t)}
                                      className="p-1.5 text-slate-500 hover:text-red-600 hover:bg-red-50 rounded-lg transition cursor-pointer"
                                      title="Editar boleta"
                                    >
                                      <Edit3 className="w-4 h-4" />
                                    </button>
                                    <button
                                      onClick={() =>
                                        setDeleteConfirm({
                                          isOpen: true,
                                          type: 'ticket',
                                          id: t.id,
                                          label: `Boleta #${getTicketBoleta(t)} (Paquete ${getTicketPaquete(t)} - ${getTicketResponsable(t)})`
                                        })
                                      }
                                      className="p-1.5 text-slate-500 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition cursor-pointer"
                                      title="Eliminar boleta"
                                    >
                                      <Trash2 className="w-4 h-4" />
                                    </button>
                                  </div>
                                </td>
                              )}
                            </tr>
                          );
                        })}
                      </tbody>
                    </table>
                  </div>
                )}
              </div>
            )}

            {/* ==========================================
                PESTAÑA 4: DASHBOARD DE AVANCE Y RANKING DE VENDEDORES DE PREMIOS
               ========================================== */}
            {activeTab === 'dashboard' && (
              <div className="space-y-8">
                {/* SECCIÓN 1: PORCENTAJE DE SORTEOS JUGADOS A LA FECHA */}
                <div className="bg-white rounded-2xl shadow-sm border border-slate-200 p-6 sm:p-8">
                  <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
                    <div className="space-y-1">
                      <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wider bg-red-50 text-red-700">
                        <TrendingUp className="w-3.5 h-3.5" /> Progreso General de la Rifa
                      </span>
                      <h2 className="text-2xl font-extrabold text-slate-900">
                        Avance de Sorteos a la Fecha
                      </h2>
                      <p className="text-sm text-slate-500">
                        Porcentaje de sorteos que ya tienen ganador asignado frente al total de premios programados.
                      </p>
                    </div>

                    <div className="flex items-center gap-4 bg-slate-50 px-5 py-4 rounded-2xl border border-slate-200 shrink-0">
                      <div className="text-right">
                        <div className="text-xs font-bold uppercase text-slate-400">Cumplimiento</div>
                        <div className="text-3xl sm:text-4xl font-black text-red-600">
                          {dashboardMetrics.progressPercentage}%
                        </div>
                      </div>
                      <div className="h-10 w-px bg-slate-200" />
                      <div className="text-xs space-y-1 text-slate-600">
                        <div>
                          <strong className="text-amber-700 font-extrabold">{dashboardMetrics.completedDraws}</strong> sorteos jugados
                        </div>
                        <div>
                          <strong className="text-amber-700 font-extrabold">{dashboardMetrics.pendingDraws}</strong> por jugar
                        </div>
                        <div>
                          <strong className="text-slate-900 font-extrabold">{dashboardMetrics.totalDraws}</strong> sorteos en total
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Barra de progreso visual */}
                  <div className="mt-6">
                    <div className="w-full h-4 bg-slate-100 rounded-full overflow-hidden border border-slate-200 p-0.5">
                      <div
                        className="h-full rounded-full bg-gradient-to-r from-red-600 via-rose-500 to-amber-500 transition-all duration-500"
                        style={{ width: `${dashboardMetrics.progressPercentage}%` }}
                      />
                    </div>
                    <div className="flex justify-between text-xs font-semibold text-slate-500 mt-2">
                      <span>0% Inicio</span>
                      <span>
                        {dashboardMetrics.completedDraws} de {dashboardMetrics.totalDraws} premios entregados ({dashboardMetrics.progressPercentage}%)
                      </span>
                      <span>100% Meta</span>
                    </div>
                  </div>
                </div>

                {/* SECCIÓN 2: RECONOCIMIENTO AL TOP 3 DE MEJORES VENDEDORES DE PREMIOS */}
                <div className="bg-gradient-to-br from-slate-900 via-red-950 to-slate-900 text-white rounded-2xl shadow-lg p-6 sm:p-8 border border-red-800/50">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-8">
                    <div>
                      <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wider bg-amber-400/20 text-amber-300 border border-amber-400/30 mb-2">
                        <Crown className="w-3.5 h-3.5 text-amber-400" /> Cuadro de Honor
                      </span>
                      <h2 className="text-2xl sm:text-3xl font-extrabold tracking-tight">
                        Top 3 Mejores Vendedores de Premios
                      </h2>
                      <p className="text-red-200 text-sm mt-0.5">
                        Reconocimiento especial a los responsables que han entregado la mayor cantidad de premios ganadores.
                      </p>
                    </div>
                    <Trophy className="w-12 h-12 text-amber-400 shrink-0 hidden sm:block opacity-90" />
                  </div>

                  {dashboardMetrics.top3.length === 0 ? (
                    <div className="bg-white/5 border border-white/10 rounded-2xl p-10 text-center">
                      <Medal className="w-12 h-12 text-amber-300/50 mx-auto mb-3" />
                      <h3 className="text-lg font-bold text-white">Aún no hay vendedores con premios registrados</h3>
                      <p className="text-sm text-red-200 max-w-md mx-auto mt-1">
                        A medida que registres los números ganadores o el campo "Vendido por:" en la pestaña de Premios Sorteados, el Top 3 se calculará automáticamente.
                      </p>
                    </div>
                  ) : (
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-5 items-stretch">
                      {dashboardMetrics.top3.map((seller, idx) => {
                        const styles = [
                          {
                            badge: '🥇 1° Lugar • Campeón en Ventas de Premios',
                            cardBg: 'bg-gradient-to-b from-amber-400/25 via-amber-500/10 to-white/5 border-2 border-amber-400 shadow-xl',
                            circleBg: 'bg-amber-400 text-slate-950',
                            countText: 'text-amber-300',
                            pillBg: 'bg-amber-400/20 text-amber-200 border-amber-400/40'
                          },
                          {
                            badge: '🥈 2° Lugar • Destacado de Plata',
                            cardBg: 'bg-gradient-to-b from-slate-300/20 via-slate-400/10 to-white/5 border border-slate-300/50',
                            circleBg: 'bg-slate-200 text-slate-900',
                            countText: 'text-slate-200',
                            pillBg: 'bg-slate-300/20 text-slate-200 border-slate-300/40'
                          },
                          {
                            badge: '🥉 3° Lugar • Destacado de Bronce',
                            cardBg: 'bg-gradient-to-b from-orange-400/20 via-orange-500/10 to-white/5 border border-orange-400/50',
                            circleBg: 'bg-orange-400 text-slate-950',
                            countText: 'text-orange-300',
                            pillBg: 'bg-orange-400/20 text-orange-200 border-orange-400/40'
                          }
                        ][idx];

                        return (
                          <div
                            key={seller.responsable}
                            className={`rounded-2xl p-6 flex flex-col justify-between transition transform hover:-translate-y-1 ${styles.cardBg}`}
                          >
                            <div>
                              <div className="flex items-center justify-between gap-2 mb-4">
                                <span className={`px-3 py-1 rounded-full text-xs font-extrabold border ${styles.pillBg}`}>
                                  {styles.badge}
                                </span>
                                <div className={`w-10 h-10 rounded-xl font-black text-lg flex items-center justify-center shrink-0 shadow-md ${styles.circleBg}`}>
                                  #{idx + 1}
                                </div>
                              </div>

                              <div className="text-xs uppercase tracking-wider text-red-200 font-semibold">
                                Responsable
                              </div>
                              <h3 className="text-2xl font-black text-white mt-0.5 break-words">
                                {seller.responsable}
                              </h3>

                              <div className="mt-4 flex items-baseline gap-2">
                                <span className={`text-4xl font-black ${styles.countText}`}>
                                  {seller.prizesCount}
                                </span>
                                <span className="text-sm text-red-100 font-semibold">
                                  {seller.prizesCount === 1 ? 'premio vendido' : 'premios vendidos'}
                                </span>
                              </div>
                            </div>

                            <div className="mt-5 pt-4 border-t border-white/10 space-y-1.5">
                              <div className="text-[11px] font-bold uppercase text-red-200">
                                Sorteos Ganadores Entregados:
                              </div>
                              <div className="flex flex-wrap gap-1.5">
                                {seller.prizesWon.map((pw, i) => (
                                  <span
                                    key={i}
                                    className="px-2.5 py-1 rounded-lg bg-white/10 text-white text-xs font-medium border border-white/10"
                                  >
                                    {pw.drawNumber}: <strong>{pw.prize}</strong> {pw.winningNumber ? `(#${pw.winningNumber})` : ''}
                                  </span>
                                ))}
                              </div>
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  )}
                </div>

                {/* SECCIÓN 3: RANKING GENERAL DE RESPONSABLES QUE MÁS PREMIOS HAN VENDIDO */}
                <div className="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden">
                  <div className="p-6 border-b border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                    <div>
                      <h3 className="text-xl font-extrabold text-slate-900">
                        Ranking Completo de Responsables por Premios Vendidos
                      </h3>
                      <p className="text-xs text-slate-500 mt-0.5">
                        Listado ordenado de mayor a menor según la cantidad de sorteos ganadores vendidos por cada responsable.
                      </p>
                    </div>
                    <span className="px-3 py-1.5 rounded-xl bg-slate-100 text-slate-700 font-bold text-xs self-start sm:self-center">
                      {dashboardMetrics.rankingList.length} responsables con premios
                    </span>
                  </div>

                  {dashboardMetrics.rankingList.length === 0 ? (
                    <div className="p-10 text-center text-slate-500 text-sm">
                      Todavía no se han registrado premios vendidos por responsables.
                    </div>
                  ) : (
                    <div className="overflow-x-auto">
                      <table className="w-full border-collapse text-sm">
                        <thead>
                          <tr className="bg-slate-900 text-white font-bold text-left">
                            <th className="py-3 px-4 text-center w-20">Posición</th>
                            <th className="py-3 px-4">Responsable (Vendido por)</th>
                            <th className="py-3 px-4 text-center">Premios Vendidos</th>
                            <th className="py-3 px-4 text-center">Boletas Asignadas en Base</th>
                            <th className="py-3 px-4">Detalle de Premios Entregados</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-slate-200">
                          {dashboardMetrics.rankingList.map((item, index) => {
                            const maxPrizes = dashboardMetrics.rankingList[0]?.prizesCount || 1;
                            const barWidth = Math.round((item.prizesCount / maxPrizes) * 100);
                            return (
                              <tr key={item.responsable} className="hover:bg-red-50/40 transition">
                                <td className="py-3.5 px-4 text-center font-black">
                                  {index === 0 ? (
                                    <span className="inline-flex items-center justify-center px-2.5 py-1 rounded-lg bg-amber-400 text-slate-950 text-xs font-black">
                                      🥇 #1
                                    </span>
                                  ) : index === 1 ? (
                                    <span className="inline-flex items-center justify-center px-2.5 py-1 rounded-lg bg-slate-200 text-slate-900 text-xs font-black">
                                      🥈 #2
                                    </span>
                                  ) : index === 2 ? (
                                    <span className="inline-flex items-center justify-center px-2.5 py-1 rounded-lg bg-orange-300 text-slate-950 text-xs font-black">
                                      🥉 #3
                                    </span>
                                  ) : (
                                    <span className="text-slate-500 font-bold">#{index + 1}</span>
                                  )}
                                </td>
                                <td className="py-3.5 px-4">
                                  <div className="font-extrabold text-slate-900 text-base">
                                    {item.responsable}
                                  </div>
                                  <div className="w-full max-w-xs h-1.5 bg-slate-100 rounded-full mt-1.5 overflow-hidden">
                                    <div
                                      className="h-full bg-red-600 rounded-full"
                                      style={{ width: `${barWidth}%` }}
                                    />
                                  </div>
                                </td>
                                <td className="py-3.5 px-4 text-center">
                                  <span className="inline-flex items-center justify-center px-3 py-1 rounded-xl bg-amber-100 text-amber-900 font-black text-base border border-amber-200">
                                    {item.prizesCount}
                                  </span>
                                </td>
                                <td className="py-3.5 px-4 text-center font-semibold text-slate-600">
                                  {item.totalBoletas > 0 ? `${item.totalBoletas} boletas` : '—'}
                                </td>
                                <td className="py-3.5 px-4">
                                  <div className="flex flex-wrap gap-1.5">
                                    {item.prizesWon.map((pw, idxP) => (
                                      <span
                                        key={idxP}
                                        className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-slate-100 text-slate-800 text-xs font-semibold border border-slate-200"
                                      >
                                        <Trophy className="w-3 h-3 text-amber-500" />
                                        {pw.drawNumber}: {pw.prize} {pw.winningNumber ? `(#${pw.winningNumber})` : ''}
                                      </span>
                                    ))}
                                  </div>
                                </td>
                              </tr>
                            );
                          })}
                        </tbody>
                      </table>
                    </div>
                  )}
                </div>
              </div>
            )}
          </>
        )}
      </main>

      {/* ==========================================
          MODAL RÁPIDO: INGRESAR NÚMERO GANADOR Y AUTOCOMPLETAR "VENDIDO POR:"
         ========================================== */}
      {quickAssignModal.isOpen && quickAssignModal.draw && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-4">
          <div className="bg-white rounded-2xl max-w-md w-full p-6 shadow-xl border border-slate-200">
            <div className="flex items-center justify-between pb-3 border-b border-slate-200">
              <div className="flex items-center gap-2.5">
                <div className="p-2 bg-amber-100 text-amber-700 rounded-xl">
                  <Trophy className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-base font-extrabold text-slate-900">
                    Declarar Número Ganador — {quickAssignModal.draw.drawNumber}
                  </h3>
                  <p className="text-xs text-slate-500">
                    Premio: <strong>{quickAssignModal.draw.prizeDescription}</strong>
                  </p>
                </div>
              </div>
              <button
                onClick={() => setQuickAssignModal({ isOpen: false, draw: null, winningNumber: '', sellerName: '', ticketInfo: '', lookupStatus: null })}
                className="text-slate-400 hover:text-slate-600 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveQuickAssign} className="space-y-4 mt-4">
              <div>
                <label className="block text-xs font-bold uppercase text-slate-700 mb-1">
                  Digita el Número Ganador *
                </label>
                <input
                  type="text"
                  required
                  autoFocus
                  value={quickAssignModal.winningNumber}
                  onChange={(e) => handleQuickAssignNumberChange(e.target.value)}
                  placeholder="Ej. 0124"
                  className="w-full px-4 py-3 text-center text-2xl font-black tracking-wider rounded-xl border-2 border-amber-400 bg-amber-50/40 focus:bg-white focus:border-amber-500 outline-none"
                />
              </div>

              {quickAssignModal.lookupStatus === 'found' && (
                <div className="p-3 rounded-xl bg-amber-50 border border-amber-200 text-amber-900 text-xs flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-amber-600 shrink-0" />
                  <div>
                    <strong>¡Número localizado en la Base de Datos de Boletas!</strong>
                    <div>Responsable (Vendido por): <strong>{quickAssignModal.sellerName}</strong></div>
                    {quickAssignModal.ticketInfo && <div>Detalle: <strong>{quickAssignModal.ticketInfo}</strong></div>}
                  </div>
                </div>
              )}

              {quickAssignModal.lookupStatus === 'not_found' && (
                <div className="p-3 rounded-xl bg-amber-50 border border-amber-200 text-amber-900 text-xs">
                  Este número no aparece en Numero 1, 2, 3 ni 4 de la base de datos. Puedes escribir manualmente quién lo vendió abajo.
                </div>
              )}

              <div>
                <label className="block text-xs font-bold uppercase text-slate-600 mb-1">
                  Vendido por (Responsable):
                </label>
                <input
                  type="text"
                  value={quickAssignModal.sellerName}
                  onChange={(e) => setQuickAssignModal({ ...quickAssignModal, sellerName: e.target.value })}
                  placeholder="Nombre del Responsable..."
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-sm font-semibold outline-none focus:ring-2 focus:ring-[#b91c1c]"
                />
              </div>

              <div className="flex justify-end gap-2 pt-3 border-t border-slate-200">
                <button
                  type="button"
                  onClick={() => setQuickAssignModal({ isOpen: false, draw: null, winningNumber: '', sellerName: '', ticketInfo: '', lookupStatus: null })}
                  className="px-4 py-2 rounded-xl border border-slate-300 text-xs font-semibold text-slate-600 cursor-pointer"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-[#b91c1c] hover:bg-[#991b1b] text-white text-xs font-bold shadow-xs cursor-pointer"
                >
                  Guardar Ganador
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ==========================================
          MODAL: CREAR / EDITAR BOLETA INDIVIDUAL (7 COLUMNAS)
         ========================================== */}
      {isTicketModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-4 overflow-y-auto">
          <div className="bg-white rounded-2xl max-w-lg w-full p-6 shadow-xl border border-slate-200">
            <div className="flex items-center justify-between pb-4 border-b border-slate-200">
              <div className="flex items-center gap-2.5">
                <div className="p-2 bg-red-100 text-red-700 rounded-xl">
                  <Ticket className="w-5 h-5" />
                </div>
                <h3 className="text-lg font-extrabold text-slate-900">
                  {isEditingTicket ? `Editar Boleta #${ticketForm.boleta}` : 'Registrar Nueva Boleta'}
                </h3>
              </div>
              <button
                onClick={() => setIsTicketModalOpen(false)}
                className="text-slate-400 hover:text-slate-600 p-1 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveTicket} className="space-y-4 mt-4">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold uppercase text-slate-600 mb-1">
                    Paquete *
                  </label>
                  <input
                    type="text"
                    required
                    value={ticketForm.paquete}
                    onChange={(e) => setTicketForm({ ...ticketForm, paquete: e.target.value })}
                    placeholder="Ej. 1"
                    className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 font-bold text-sm focus:ring-2 focus:ring-red-500 outline-none"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold uppercase text-slate-600 mb-1">
                    Boleta *
                  </label>
                  <input
                    type="text"
                    required
                    value={ticketForm.boleta}
                    onChange={(e) => setTicketForm({ ...ticketForm, boleta: e.target.value })}
                    placeholder="Ej. 1"
                    className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 font-black text-base focus:ring-2 focus:ring-red-500 outline-none"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold uppercase text-red-700 mb-1.5">
                  Los 4 Números de la Boleta
                </label>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
                  <div>
                    <span className="block text-[10px] font-bold uppercase text-slate-500 mb-1">Numero 1 *</span>
                    <input
                      type="text"
                      required
                      value={ticketForm.numero1}
                      onChange={(e) => setTicketForm({ ...ticketForm, numero1: e.target.value })}
                      placeholder="0124"
                      className="w-full px-3 py-2 rounded-xl border border-slate-300 font-mono font-bold text-center text-sm focus:ring-2 focus:ring-red-500 outline-none"
                    />
                  </div>
                  <div>
                    <span className="block text-[10px] font-bold uppercase text-slate-500 mb-1">Numero 2</span>
                    <input
                      type="text"
                      value={ticketForm.numero2}
                      onChange={(e) => setTicketForm({ ...ticketForm, numero2: e.target.value })}
                      placeholder="2624"
                      className="w-full px-3 py-2 rounded-xl border border-slate-300 font-mono font-bold text-center text-sm focus:ring-2 focus:ring-red-500 outline-none"
                    />
                  </div>
                  <div>
                    <span className="block text-[10px] font-bold uppercase text-slate-500 mb-1">Numero 3</span>
                    <input
                      type="text"
                      value={ticketForm.numero3}
                      onChange={(e) => setTicketForm({ ...ticketForm, numero3: e.target.value })}
                      placeholder="5124"
                      className="w-full px-3 py-2 rounded-xl border border-slate-300 font-mono font-bold text-center text-sm focus:ring-2 focus:ring-red-500 outline-none"
                    />
                  </div>
                  <div>
                    <span className="block text-[10px] font-bold uppercase text-slate-500 mb-1">Numero 4</span>
                    <input
                      type="text"
                      value={ticketForm.numero4}
                      onChange={(e) => setTicketForm({ ...ticketForm, numero4: e.target.value })}
                      placeholder="7624"
                      className="w-full px-3 py-2 rounded-xl border border-slate-300 font-mono font-bold text-center text-sm focus:ring-2 focus:ring-red-500 outline-none"
                    />
                  </div>
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold uppercase text-slate-600 mb-1">
                  Responsable *
                </label>
                <input
                  type="text"
                  required
                  value={ticketForm.responsable}
                  onChange={(e) => setTicketForm({ ...ticketForm, responsable: e.target.value })}
                  placeholder="Nombre de la persona responsable de la boleta"
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-sm font-semibold focus:ring-2 focus:ring-red-500 outline-none"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-200">
                <button
                  type="button"
                  onClick={() => setIsTicketModalOpen(false)}
                  className="px-4 py-2.5 rounded-xl border border-slate-300 text-slate-600 hover:bg-slate-100 text-sm font-semibold cursor-pointer"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="px-5 py-2.5 rounded-xl bg-red-600 hover:bg-red-700 text-white text-sm font-bold shadow-xs cursor-pointer"
                >
                  {isEditingTicket ? 'Guardar Cambios' : 'Guardar Boleta'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ==========================================
          MODAL: IMPORTACIÓN MASIVA DE BOLETAS DESDE EXCEL (7 COLUMNAS)
         ========================================== */}
      {isBulkModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-4 overflow-y-auto">
          <div className="bg-white rounded-2xl max-w-2xl w-full p-6 shadow-xl border border-slate-200">
            <div className="flex items-center justify-between pb-4 border-b border-slate-200">
              <div className="flex items-center gap-2.5">
                <div className="p-2 bg-red-100 text-red-700 rounded-xl">
                  <Upload className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-lg font-extrabold text-slate-900">
                    Importar Base de Datos de Boletas desde Excel
                  </h3>
                  <p className="text-xs text-slate-500">
                    Copia y pega tus filas directamente desde Excel con las 7 columnas oficiales
                  </p>
                </div>
              </div>
              <button
                onClick={() => setIsBulkModalOpen(false)}
                className="text-slate-400 hover:text-slate-600 p-1 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleBulkImport} className="space-y-4 mt-4">
              <div className="bg-slate-50 p-3.5 rounded-xl border border-slate-200 text-xs text-slate-600 space-y-2">
                <div className="font-bold text-slate-800">
                  Estructura exacta de columnas (puedes pegar directo desde Excel):
                </div>
                <div className="grid grid-cols-7 bg-white text-slate-900 font-bold text-[11px] text-center border-2 border-slate-800">
                  <div className="py-1.5 px-1 border-r border-slate-400">Paquete</div>
                  <div className="py-1.5 px-1 border-r border-slate-400">Boleta</div>
                  <div className="py-1.5 px-1 border-r border-slate-400">Numero 1</div>
                  <div className="py-1.5 px-1 border-r border-slate-400">Numero 2</div>
                  <div className="py-1.5 px-1 border-r border-slate-400">Numero 3</div>
                  <div className="py-1.5 px-1 border-r border-slate-400">Numero 4</div>
                  <div className="py-1.5 px-1">Responsable</div>
                </div>
              </div>

              <div>
                <div className="flex items-center justify-between mb-1.5">
                  <label className="text-xs font-bold uppercase text-slate-600">
                    Pega aquí tus filas de Excel (1 boleta por línea)
                  </label>
                  <button
                    type="button"
                    onClick={() =>
                      setBulkText(
                        `1\t1\t0124\t2624\t5124\t7624\tLaura Gómez\n1\t2\t0389\t2889\t5389\t7889\tLaura Gómez\n1\t3\t0512\t3012\t5512\t8012\tAndrés Pérez\n2\t4\t1045\t3545\t6045\t8545\tCamila Torres`
                      )
                    }
                    className="text-[11px] font-bold text-red-600 hover:underline cursor-pointer"
                  >
                    + Cargar ejemplo con las 7 columnas
                  </button>
                </div>
                <textarea
                  rows={7}
                  required
                  value={bulkText}
                  onChange={(e) => setBulkText(e.target.value)}
                  placeholder={`1\t1\t0124\t2624\t5124\t7624\tLaura Gómez\n1\t2\t0389\t2889\t5389\t7889\tAndrés Pérez`}
                  className="w-full p-3.5 rounded-xl border border-slate-300 font-mono text-xs focus:ring-2 focus:ring-red-500 outline-none"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-200">
                <button
                  type="button"
                  onClick={() => setIsBulkModalOpen(false)}
                  className="px-4 py-2.5 rounded-xl border border-slate-300 text-slate-600 hover:bg-slate-100 text-sm font-semibold cursor-pointer"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  disabled={isImporting}
                  className="px-5 py-2.5 rounded-xl bg-red-600 hover:bg-red-700 text-white text-sm font-bold shadow-xs disabled:opacity-50 cursor-pointer"
                >
                  {isImporting ? 'Importando...' : 'Importar Base de Boletas'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ==========================================
          MODAL: IMPORTACIÓN MASIVA DE PREMIOS SORTEADOS DESDE EXCEL
         ========================================== */}
      {isBulkWinnerModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-4 overflow-y-auto">
          <div className="bg-white rounded-2xl max-w-2xl w-full p-6 shadow-xl border border-slate-200">
            <div className="flex items-center justify-between pb-4 border-b border-slate-200">
              <div className="flex items-center gap-2.5">
                <div className="p-2 bg-rose-100 text-[#b91c1c] rounded-xl">
                  <Trophy className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-lg font-extrabold text-slate-900">
                    Importar Lista de Premios Sorteados
                  </h3>
                  <p className="text-xs text-slate-500">
                    Copia y pega tus filas directamente desde Excel
                  </p>
                </div>
              </div>
              <button
                onClick={() => setIsBulkWinnerModalOpen(false)}
                className="text-slate-400 hover:text-slate-600 p-1 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleBulkWinnerImport} className="space-y-4 mt-4">
              <div className="bg-slate-50 p-3.5 rounded-xl border border-slate-200 text-xs text-slate-600 space-y-2">
                <div className="font-bold text-slate-800">
                  Estructura de columnas (puedes pegar directo desde Excel):
                </div>
                <div className="grid grid-cols-5 bg-[#c8102e] text-white font-bold text-[11px] text-center border border-slate-800">
                  <div className="py-1.5 px-1 border-r border-slate-800/40">Numero de Sorteo</div>
                  <div className="py-1.5 px-1 border-r border-slate-800/40">Premio</div>
                  <div className="py-1.5 px-1 border-r border-slate-800/40">Lotería</div>
                  <div className="py-1.5 px-1 border-r border-slate-800/40">Fecha del Sorteo</div>
                  <div className="py-1.5 px-1">Vendido por: / N° Ganador</div>
                </div>
              </div>

              <div>
                <div className="flex items-center justify-between mb-1.5">
                  <label className="text-xs font-bold uppercase text-slate-600">
                    Pega aquí tus filas de Excel (1 sorteo por línea)
                  </label>
                  <button
                    type="button"
                    onClick={() =>
                      setBulkWinnerText(
                        `Sorteo 1\tBono $1.000.000\tLotería de Boyacá\t15/06/2025\t0124\nSorteo 2\tMoto Yamaha 125cc\tLotería de Medellín\t22/06/2025\t5389\nSorteo 3\tBono $2.000.000\tCruz Roja\t29/06/2025\t`
                      )
                    }
                    className="text-[11px] font-bold text-[#b91c1c] hover:underline cursor-pointer"
                  >
                    + Cargar ejemplo de sorteos
                  </button>
                </div>
                <textarea
                  rows={6}
                  required
                  value={bulkWinnerText}
                  onChange={(e) => setBulkWinnerText(e.target.value)}
                  placeholder={`Sorteo 1\tBono $1.000.000\tBoyacá\t15/06/2025\t0124\nSorteo 2\tMoto Yamaha\tMedellín\t22/06/2025\t`}
                  className="w-full p-3.5 rounded-xl border border-slate-300 font-mono text-xs focus:ring-2 focus:ring-[#b91c1c] outline-none"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-200">
                <button
                  type="button"
                  onClick={() => setIsBulkWinnerModalOpen(false)}
                  className="px-4 py-2.5 rounded-xl border border-slate-300 text-slate-600 hover:bg-slate-100 text-sm font-semibold cursor-pointer"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  disabled={isImportingWinners}
                  className="px-5 py-2.5 rounded-xl bg-[#b91c1c] hover:bg-[#991b1b] text-white text-sm font-bold shadow-xs disabled:opacity-50 cursor-pointer"
                >
                  {isImportingWinners ? 'Importando...' : 'Importar Premios Sorteados'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ==========================================
          MODAL: ACCESO ADMINISTRADOR (PIN)
         ========================================== */}
      {isPinModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-4">
          <div className="bg-white rounded-2xl max-w-sm w-full p-6 shadow-xl border border-slate-200">
            <div className="flex items-center justify-between pb-3 border-b border-slate-200">
              <div className="flex items-center gap-2">
                <KeyRound className="w-5 h-5 text-red-600" />
                <h3 className="text-base font-extrabold text-slate-900">Desbloquear Modo Administrador</h3>
              </div>
              <button onClick={() => setIsPinModalOpen(false)} className="text-slate-400 hover:text-slate-600 cursor-pointer">
                <X className="w-5 h-5" />
              </button>
            </div>
            <form onSubmit={handleAdminLogin} className="space-y-4 mt-4">
              <p className="text-xs text-slate-500">
                Ingresa tu PIN de administrador para habilitar la edición e importación de boletas y premios. (PIN inicial por defecto: <strong>1234</strong>)
              </p>
              <input
                type="password"
                required
                autoFocus
                value={pinInput}
                onChange={(e) => setPinInput(e.target.value)}
                placeholder="Ingresa el PIN..."
                className="w-full px-4 py-3 text-center text-xl font-black tracking-widest rounded-xl border-2 border-red-200 focus:border-red-600 outline-none"
              />
              <button
                type="submit"
                className="w-full py-2.5 rounded-xl bg-red-600 hover:bg-red-700 text-white font-bold text-sm shadow-xs cursor-pointer"
              >
                Ingresar como Administrador
              </button>
            </form>
          </div>
        </div>
      )}

      {/* ==========================================
          MODAL: AJUSTES DE ADMINISTRADOR Y SEGURIDAD
         ========================================== */}
      {isSettingsModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-4">
          <div className="bg-white rounded-2xl max-w-md w-full p-6 shadow-xl border border-slate-200">
            <div className="flex items-center justify-between pb-3 border-b border-slate-200">
              <div className="flex items-center gap-2">
                <Settings className="w-5 h-5 text-red-600" />
                <h3 className="text-base font-extrabold text-slate-900">Configuración de Rifa y Seguridad</h3>
              </div>
              <button onClick={() => setIsSettingsModalOpen(false)} className="text-slate-400 hover:text-slate-600 cursor-pointer">
                <X className="w-5 h-5" />
              </button>
            </div>
            <form onSubmit={handleSaveSettings} className="space-y-4 mt-4">
              <div>
                <label className="block text-xs font-bold uppercase text-slate-600 mb-1">Título de la Rifa</label>
                <input
                  type="text"
                  value={settingsForm.raffleTitle}
                  onChange={(e) => setSettingsForm({ ...settingsForm, raffleTitle: e.target.value })}
                  className="w-full px-3.5 py-2 rounded-xl border border-slate-300 text-sm outline-none focus:ring-2 focus:ring-red-500"
                />
              </div>
              <div>
                <label className="block text-xs font-bold uppercase text-slate-600 mb-1">PIN de Administrador</label>
                <input
                  type="text"
                  required
                  value={settingsForm.newPin}
                  onChange={(e) => setSettingsForm({ ...settingsForm, newPin: e.target.value })}
                  className="w-full px-3.5 py-2 rounded-xl border border-slate-300 text-sm font-bold outline-none focus:ring-2 focus:ring-red-500"
                />
              </div>
              <div className="flex justify-end gap-2 pt-3 border-t border-slate-200">
                <button
                  type="button"
                  onClick={() => setIsSettingsModalOpen(false)}
                  className="px-4 py-2 rounded-xl border border-slate-300 text-xs font-semibold text-slate-600 cursor-pointer"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 rounded-xl bg-red-600 text-white text-xs font-bold cursor-pointer"
                >
                  Guardar Ajustes
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ==========================================
          MODAL: COMPARTIR APP EN MODO CONSULTA
         ========================================== */}
      {isShareModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-4">
          <div className="bg-white rounded-2xl max-w-md w-full p-6 shadow-xl border border-slate-200">
            <div className="flex items-center justify-between pb-3 border-b border-slate-200">
              <div className="flex items-center gap-2">
                <Share2 className="w-5 h-5 text-red-600" />
                <h3 className="text-base font-extrabold text-slate-900">Compartir en Modo Solo Lectura</h3>
              </div>
              <button onClick={() => setIsShareModalOpen(false)} className="text-slate-400 hover:text-slate-600 cursor-pointer">
                <X className="w-5 h-5" />
              </button>
            </div>
            <div className="space-y-3.5 mt-4 text-xs text-slate-600">
              <p>
                Por seguridad, <strong>cualquier persona que abra el enlace de esta aplicación entra automáticamente en Modo Consulta (Solo Lectura)</strong>.
              </p>

              <div className="bg-red-50 p-3.5 rounded-xl border border-red-200 space-y-2 text-red-950">
                <div className="font-extrabold flex items-center gap-1.5">
                  <ShieldCheck className="w-4 h-4 text-red-600" />
                  Pasos recomendados antes de compartir:
                </div>
                <ol className="list-decimal pl-4 space-y-1">
                  <li>
                    Si estás en Modo Administrador, entra a <strong>Ajustes Admin</strong> y cambia el PIN por defecto (<code>1234</code>) por tu clave personal secreta.
                  </li>
                  <li>
                    Haz clic en el botón <strong>"Bloquear"</strong> arriba a la derecha al terminar de editar.
                  </li>
                  <li>
                    Comparte el enlace público de la aplicación por WhatsApp o redes sociales.
                  </li>
                </ol>
              </div>

              <div className="bg-slate-50 p-3 rounded-xl border border-slate-200 space-y-1.5">
                <div className="font-bold text-slate-800">¿Qué verán los terceros invitados?</div>
                <ul className="list-disc pl-4 space-y-1">
                  <li>Podrán buscar cualquier número y ver su Boleta, Paquete y Responsable.</li>
                  <li>Verán la tabla de Premios Sorteados y el nuevo <strong>Dashboard con el Top 3</strong> en tiempo real.</li>
                  <li><strong>No verán</strong> botones para editar, borrar ni importar datos.</li>
                </ul>
              </div>

              <div className="flex items-center justify-between gap-2 pt-2">
                <button
                  onClick={() => copyToClipboard(window.location.href, "Enlace de la aplicación copiado al portapapeles")}
                  className="flex-1 inline-flex items-center justify-center gap-1.5 px-4 py-2.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-800 font-bold text-xs transition cursor-pointer"
                >
                  <Copy className="w-4 h-4 text-red-600" />
                  Copiar Enlace Actual
                </button>
                <button
                  onClick={() => setIsShareModalOpen(false)}
                  className="px-4 py-2.5 rounded-xl bg-red-600 hover:bg-red-700 text-white font-bold text-xs cursor-pointer"
                >
                  Entendido
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ==========================================
          MODAL: CONFIRMACIÓN DE ELIMINACIÓN
         ========================================== */}
      {deleteConfirm.isOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-4">
          <div className="bg-white rounded-2xl max-w-sm w-full p-6 shadow-xl border border-slate-200 text-center">
            <div className="w-12 h-12 rounded-2xl bg-rose-100 text-rose-600 flex items-center justify-center mx-auto mb-3">
              <Trash2 className="w-6 h-6" />
            </div>
            <h3 className="text-lg font-extrabold text-slate-900">¿Eliminar este registro?</h3>
            <p className="text-sm text-slate-600 mt-1">
              Estás por eliminar <strong className="text-slate-900">{deleteConfirm.label}</strong>. Esta acción no se puede deshacer.
            </p>
            <div className="flex items-center justify-center gap-3 mt-6">
              <button
                onClick={() => setDeleteConfirm({ isOpen: false, type: '', id: '', label: '' })}
                className="flex-1 py-2.5 px-4 rounded-xl border border-slate-300 text-slate-700 font-semibold text-sm hover:bg-slate-100"
              >
                Cancelar
              </button>
              <button
                onClick={confirmDelete}
                className="flex-1 py-2.5 px-4 rounded-xl bg-rose-600 hover:bg-rose-700 text-white font-bold text-sm shadow-xs"
              >
                Sí, eliminar
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}