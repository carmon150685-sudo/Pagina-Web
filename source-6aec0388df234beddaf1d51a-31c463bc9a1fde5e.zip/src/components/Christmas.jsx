import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';

/* ------------------------------------------------------------------ */
/*  Ilustraciones SVG originales                                       */
/* ------------------------------------------------------------------ */

export function SantaFigure({ className = '', waving = true }) {
  return (
    <svg viewBox="0 0 200 240" className={className} role="img" aria-label="Papá Noel saludando">
      {/* Cuerpo */}
      <path d="M40 230 Q40 140 100 130 Q160 140 160 230 Z" fill="#c8102e" />
      <rect x="40" y="200" width="120" height="16" fill="#1f2937" />
      <rect x="88" y="198" width="24" height="20" rx="3" fill="#fbbf24" />
      <rect x="94" y="203" width="12" height="10" rx="2" fill="#1f2937" />
      <path d="M96 140 L104 140 L104 230 L96 230 Z" fill="#fff" opacity="0.9" />
      {/* Brazo izquierdo */}
      <path d="M48 160 Q25 185 34 205" stroke="#c8102e" strokeWidth="20" fill="none" strokeLinecap="round" />
      <circle cx="34" cy="208" r="11" fill="#fff" />
      {/* Brazo derecho (saluda) */}
      <g className={waving ? 'santa-wave' : ''} style={{ transformOrigin: '150px 155px' }}>
        <path d="M150 155 Q178 135 176 100" stroke="#c8102e" strokeWidth="20" fill="none" strokeLinecap="round" />
        <rect x="164" y="104" width="24" height="9" rx="4" fill="#fff" />
        <circle cx="176" cy="92" r="12" fill="#1f2937" />
      </g>
      {/* Barba */}
      <path d="M58 92 Q60 160 100 168 Q140 160 142 92 Z" fill="#fff" />
      {/* Cara */}
      <circle cx="100" cy="88" r="34" fill="#fcd9b8" />
      <circle cx="86" cy="84" r="4" fill="#1f2937" />
      <circle cx="114" cy="84" r="4" fill="#1f2937" />
      <circle cx="78" cy="96" r="6" fill="#f87171" opacity="0.55" />
      <circle cx="122" cy="96" r="6" fill="#f87171" opacity="0.55" />
      <circle cx="100" cy="96" r="6" fill="#f59e9e" />
      {/* Bigote */}
      <path d="M100 104 Q86 96 72 108 Q88 114 100 106 Q112 114 128 108 Q114 96 100 104 Z" fill="#fff" />
      <path d="M92 116 Q100 122 108 116" stroke="#9f1239" strokeWidth="3" fill="none" strokeLinecap="round" />
      {/* Gorro */}
      <path d="M62 70 Q70 18 120 22 Q150 26 160 62 L150 70 Z" fill="#c8102e" />
      <rect x="58" y="62" width="88" height="16" rx="8" fill="#fff" />
      <circle cx="162" cy="66" r="10" fill="#fff" />
    </svg>
  );
}

function Reindeer({ x = 0, nose = false }) {
  return (
    <g transform={`translate(${x} 0)`}>
      <g className="reindeer-legs">
        <path d="M8 46 L2 62 M14 46 L12 62 M34 46 L40 62 M40 46 L48 60" stroke="#78350f" strokeWidth="4" strokeLinecap="round" />
      </g>
      <ellipse cx="24" cy="40" rx="22" ry="10" fill="#92400e" />
      <path d="M42 36 L52 22" stroke="#92400e" strokeWidth="8" strokeLinecap="round" />
      <ellipse cx="58" cy="20" rx="10" ry="7" fill="#92400e" />
      <path d="M52 14 L48 2 M48 6 L42 2 M58 13 L62 1 M61 5 L67 2" stroke="#78350f" strokeWidth="3" strokeLinecap="round" />
      <circle cx="58" cy="18" r="1.8" fill="#111" />
      <circle cx="68" cy="21" r={nose ? 4 : 2.5} fill={nose ? '#ef4444' : '#3f1d0b'} className={nose ? 'rudolph-nose' : ''} />
      <path d="M2 38 Q-4 34 0 30" stroke="#fef3c7" strokeWidth="4" fill="none" strokeLinecap="round" />
    </g>
  );
}

export function SleighSVG({ className = '' }) {
  return (
    <svg viewBox="0 0 330 90" className={className} aria-hidden="true">
      {/* Riendas */}
      <path d="M118 52 Q160 38 196 36 Q240 34 268 34" stroke="#fbbf24" strokeWidth="2" fill="none" />
      <Reindeer x={190} />
      <Reindeer x={256} nose />
      {/* Trineo */}
      <path d="M8 78 Q4 86 16 86 L120 86 Q132 86 134 76" stroke="#fbbf24" strokeWidth="4" fill="none" strokeLinecap="round" />
      <path d="M28 78 L32 70 M104 78 L100 70" stroke="#fbbf24" strokeWidth="4" />
      <path d="M14 34 L24 72 L112 72 Q128 72 128 52 L118 46 L52 46 Q40 46 36 34 Z" fill="#b91c1c" />
      <path d="M24 64 L116 64" stroke="#fbbf24" strokeWidth="3" />
      {/* Saco de regalos */}
      <path d="M22 40 Q18 10 40 8 Q60 6 58 40 Z" fill="#a16207" />
      <rect x="44" y="16" width="16" height="14" fill="#facc15" />
      <rect x="51" y="16" width="3" height="14" fill="#fde047" />
      {/* Papá Noel en el trineo */}
      <path d="M64 46 Q64 22 84 22 Q104 22 104 46 Z" fill="#c8102e" />
      <path d="M72 30 Q74 50 84 50 Q94 50 96 30 Z" fill="#fff" />
      <circle cx="84" cy="24" r="10" fill="#fcd9b8" />
      <circle cx="80" cy="23" r="1.5" fill="#111" />
      <circle cx="88" cy="23" r="1.5" fill="#111" />
      <path d="M72 18 Q78 2 96 8 L98 18 Z" fill="#c8102e" />
      <rect x="71" y="15" width="28" height="5" rx="2.5" fill="#fff" />
      <circle cx="98" cy="8" r="3.5" fill="#fff" />
      <path d="M100 34 Q112 36 120 50" stroke="#c8102e" strokeWidth="6" strokeLinecap="round" fill="none" />
    </svg>
  );
}

/* ------------------------------------------------------------------ */
/*  Nieve                                                              */
/* ------------------------------------------------------------------ */

export function Snowfall({ count = 45 }) {
  const flakes = useMemo(
    () =>
      Array.from({ length: count }, (_, i) => ({
        id: i,
        left: Math.random() * 100,
        size: 4 + Math.random() * 8,
        duration: 8 + Math.random() * 12,
        delay: -Math.random() * 20,
        drift: (Math.random() - 0.5) * 80,
        opacity: 0.4 + Math.random() * 0.5
      })),
    [count]
  );

  return (
    <div className="pointer-events-none fixed inset-0 z-30 overflow-hidden" aria-hidden="true">
      {flakes.map((f) => (
        <span
          key={f.id}
          className="snowflake"
          style={{
            left: `${f.left}%`,
            width: f.size,
            height: f.size,
            opacity: f.opacity,
            animationDuration: `${f.duration}s`,
            animationDelay: `${f.delay}s`,
            '--drift': `${f.drift}px`
          }}
        />
      ))}
    </div>
  );
}

/* ------------------------------------------------------------------ */
/*  Guirnalda de luces                                                 */
/* ------------------------------------------------------------------ */

const LIGHT_COLORS = ['#ef4444', '#facc15', '#f8fafc', '#3b82f6', '#f472b6'];

export function ChristmasLights({ count = 28 }) {
  return (
    <div className="relative h-7 overflow-hidden bg-transparent" aria-hidden="true">
      <svg className="absolute inset-x-0 top-0 h-3 w-full" preserveAspectRatio="none" viewBox="0 0 100 10">
        <path d="M0 2 Q 2.5 8 5 2 T 10 2 T 15 2 T 20 2 T 25 2 T 30 2 T 35 2 T 40 2 T 45 2 T 50 2 T 55 2 T 60 2 T 65 2 T 70 2 T 75 2 T 80 2 T 85 2 T 90 2 T 95 2 T 100 2" stroke="#78350f" strokeWidth="0.6" fill="none" />
      </svg>
      <div className="absolute inset-x-0 top-1 flex justify-between px-2">
        {Array.from({ length: count }, (_, i) => (
          <span
            key={i}
            className="xmas-bulb"
            style={{
              '--bulb': LIGHT_COLORS[i % LIGHT_COLORS.length],
              animationDelay: `${(i % 5) * 0.3}s`
            }}
          />
        ))}
      </div>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/*  Trineo interactivo                                                 */
/* ------------------------------------------------------------------ */

const GIFT_COLORS = [
  ['#ef4444', '#fde047'],
  ['#f8fafc', '#ef4444'],
  ['#3b82f6', '#f8fafc'],
  ['#a855f7', '#fbbf24'],
  ['#f59e0b', '#b91c1c']
];
const HO_HO = ['¡Jo, jo, jo!', '¡Feliz Navidad!', '¡Suerte en la rifa!', '¡Un regalo para ti!', '¡Feliz y próspero año 2027!'];

const prefersReducedMotion = () =>
  typeof window !== 'undefined' && window.matchMedia?.('(prefers-reduced-motion: reduce)').matches;

export function InteractiveSleigh() {
  const sleighRef = useRef(null);
  const state = useRef({ x: -360, t: 0, speed: 1.3, boost: 0, flying: false, dir: 1, baseY: 120 });
  const rafRef = useRef(0);
  const idleTimer = useRef(0);
  const [flying, setFlying] = useState(false);
  const [gifts, setGifts] = useState([]);
  const [bubble, setBubble] = useState(null);
  const [delivered, setDelivered] = useState(0);

  const scheduleNext = useCallback((ms) => {
    clearTimeout(idleTimer.current);
    idleTimer.current = setTimeout(() => launch(), ms);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const step = useCallback(() => {
    const s = state.current;
    const el = sleighRef.current;
    if (!el) return;
    s.t += 1;
    s.boost *= 0.97;
    s.x += (s.speed + s.boost) * s.dir;
    const y = s.baseY + Math.sin(s.t / 40) * 26;
    const tilt = Math.cos(s.t / 40) * -6 * s.dir;
    el.style.transform = `translate3d(${s.x}px, ${y}px, 0) scaleX(${s.dir}) rotate(${tilt}deg)`;

    const w = window.innerWidth;
    if ((s.dir === 1 && s.x > w + 40) || (s.dir === -1 && s.x < -400)) {
      s.flying = false;
      setFlying(false);
      scheduleNext(18000 + Math.random() * 12000);
      return;
    }
    rafRef.current = requestAnimationFrame(step);
  }, [scheduleNext]);

  const launch = useCallback(() => {
    const s = state.current;
    if (s.flying) return;
    clearTimeout(idleTimer.current);
    s.dir = Math.random() > 0.5 ? 1 : -1;
    s.x = s.dir === 1 ? -360 : window.innerWidth + 20;
    s.baseY = 70 + Math.random() * Math.min(180, window.innerHeight * 0.25);
    s.t = 0;
    s.boost = 0;
    s.speed = window.innerWidth < 640 ? 0.9 : 1.3;
    s.flying = true;
    setFlying(true);
    cancelAnimationFrame(rafRef.current);
    rafRef.current = requestAnimationFrame(step);
  }, [step]);

  useEffect(() => {
    if (prefersReducedMotion()) return undefined;
    idleTimer.current = setTimeout(launch, 2500);
    return () => {
      clearTimeout(idleTimer.current);
      cancelAnimationFrame(rafRef.current);
    };
  }, [launch]);

  const dropGifts = (e) => {
    e.stopPropagation();
    const rect = sleighRef.current?.getBoundingClientRect();
    if (!rect) return;
    state.current.boost = 3;
    const now = Date.now();
    const newGifts = Array.from({ length: 4 }, (_, i) => {
      const [box, ribbon] = GIFT_COLORS[Math.floor(Math.random() * GIFT_COLORS.length)];
      return {
        id: `${now}-${i}`,
        x: rect.left + rect.width * 0.15 + Math.random() * 60,
        y: rect.top + rect.height * 0.5,
        box,
        ribbon,
        spin: (Math.random() - 0.5) * 720,
        drift: (Math.random() - 0.5) * 160,
        delay: i * 0.12
      };
    });
    setGifts((g) => [...g, ...newGifts]);
    setDelivered((d) => d + newGifts.length);
    setBubble({ id: now, text: HO_HO[Math.floor(Math.random() * HO_HO.length)], x: rect.left + rect.width / 2, y: rect.top });
    setTimeout(() => setGifts((g) => g.filter((x) => !newGifts.includes(x))), 3200);
    setTimeout(() => setBubble((b) => (b && b.id === now ? null : b)), 1800);
  };

  return (
    <>
      {/* Trineo volador */}
      <div className="pointer-events-none fixed inset-0 z-40 overflow-hidden" aria-hidden={!flying}>
        <button
          ref={sleighRef}
          type="button"
          onClick={dropGifts}
          title="¡Haz clic para que Papá Noel reparta regalos!"
          aria-label="Trineo de Papá Noel: haz clic para lanzar regalos"
          className={`sleigh-btn pointer-events-auto absolute left-0 top-0 w-56 sm:w-80 cursor-pointer ${flying ? 'opacity-100' : 'opacity-0 pointer-events-none'}`}
          style={{ transform: 'translate3d(-400px, 100px, 0)' }}
        >
          <div className="sleigh-trail" />
          <SleighSVG className="relative w-full drop-shadow-[0_6px_10px_rgba(0,0,0,0.35)]" />
        </button>

        {gifts.map((g) => (
          <span
            key={g.id}
            className="falling-gift"
            style={{
              left: g.x,
              top: g.y,
              '--spin': `${g.spin}deg`,
              '--drift': `${g.drift}px`,
              animationDelay: `${g.delay}s`,
              background: g.box
            }}
          >
            <span style={{ background: g.ribbon }} className="gift-ribbon-v" />
            <span style={{ background: g.ribbon }} className="gift-ribbon-h" />
          </span>
        ))}

        {bubble && (
          <div
            key={bubble.id}
            className="hoho-bubble"
            style={{ left: bubble.x, top: bubble.y }}
          >
            {bubble.text}
          </div>
        )}
      </div>

      {/* Botón para llamar al trineo */}
      <button
        type="button"
        onClick={launch}
        disabled={flying}
        className="fixed bottom-5 left-5 z-40 flex items-center gap-2 rounded-full border-2 border-amber-300 bg-gradient-to-r from-red-700 to-red-600 py-2 pl-2 pr-4 text-sm font-bold text-white shadow-lg transition hover:scale-105 hover:from-red-600 hover:to-red-500 disabled:cursor-default disabled:opacity-80 disabled:hover:scale-100 cursor-pointer"
        title="Llamar al trineo de Papá Noel"
      >
        <span className="flex h-8 w-8 items-center justify-center rounded-full bg-white/15 text-lg">🛷</span>
        <span>{flying ? '¡Haz clic en el trineo!' : 'Llamar a Papá Noel'}</span>
        {delivered > 0 && (
          <span className="rounded-full bg-amber-300 px-2 py-0.5 text-xs text-red-900">🎁 {delivered}</span>
        )}
      </button>
    </>
  );
}

/* ------------------------------------------------------------------ */
/*  Escenas navideñas del banner (ilustraciones SVG originales)        */
/* ------------------------------------------------------------------ */

function TreeScene() {
  return (
    <svg viewBox="0 0 160 160" className="h-full w-full">
      <rect x="72" y="128" width="16" height="16" rx="2" fill="#7c2d12" />
      <polygon points="80,22 116,74 44,74" fill="#166534" />
      <polygon points="80,44 126,104 34,104" fill="#15803d" />
      <polygon points="80,68 136,132 24,132" fill="#166534" />
      <path d="M50 92 Q80 104 108 86" stroke="#fcd34d" strokeWidth="3" fill="none" />
      <path d="M40 120 Q80 134 122 112" stroke="#fcd34d" strokeWidth="3" fill="none" />
      {[[60, 96, '#ef4444'], [96, 92, '#facc15'], [80, 62, '#f8fafc'], [52, 124, '#facc15'], [82, 118, '#ef4444'], [112, 120, '#f8fafc'], [70, 80, '#ef4444']].map(([cx, cy, c], i) => (
        <circle key={i} cx={cx} cy={cy} r="5" fill={c} className="xmas-scene-light" style={{ animationDelay: `${i * 0.25}s` }} />
      ))}
      <polygon points="80,8 85,20 98,20 88,28 92,40 80,32 68,40 72,28 62,20 75,20" fill="#facc15" className="xmas-scene-star" />
    </svg>
  );
}

function GiftsScene() {
  return (
    <svg viewBox="0 0 160 160" className="h-full w-full">
      <rect x="22" y="78" width="64" height="58" rx="4" fill="#b91c1c" />
      <rect x="18" y="66" width="72" height="16" rx="3" fill="#dc2626" />
      <rect x="48" y="66" width="12" height="70" fill="#facc15" />
      <path d="M54 66 C38 44 26 58 54 66 C70 44 82 58 54 66" stroke="#facc15" strokeWidth="5" fill="none" />
      <rect x="92" y="96" width="48" height="40" rx="4" fill="#f8fafc" />
      <rect x="89" y="88" width="54" height="12" rx="3" fill="#e2e8f0" />
      <rect x="111" y="88" width="10" height="48" fill="#dc2626" />
      <path d="M116 88 C104 72 96 82 116 88 C128 72 136 82 116 88" stroke="#dc2626" strokeWidth="4" fill="none" />
      <rect x="64" y="112" width="36" height="26" rx="3" fill="#facc15" />
      <rect x="78" y="112" width="8" height="26" fill="#b91c1c" />
      <circle cx="34" cy="30" r="3" fill="#fde68a" className="xmas-scene-light" />
      <circle cx="128" cy="44" r="3" fill="#fde68a" className="xmas-scene-light" style={{ animationDelay: '0.6s' }} />
      <circle cx="100" cy="22" r="2" fill="#fde68a" className="xmas-scene-light" style={{ animationDelay: '1.1s' }} />
    </svg>
  );
}

function SnowmanScene() {
  return (
    <svg viewBox="0 0 160 160" className="h-full w-full">
      <ellipse cx="80" cy="146" rx="66" ry="10" fill="#e2e8f0" />
      <circle cx="80" cy="112" r="34" fill="#f8fafc" stroke="#cbd5e1" strokeWidth="2" />
      <circle cx="80" cy="62" r="24" fill="#f8fafc" stroke="#cbd5e1" strokeWidth="2" />
      <rect x="58" y="36" width="44" height="6" rx="2" fill="#1f2937" />
      <rect x="64" y="12" width="32" height="26" rx="3" fill="#1f2937" />
      <rect x="64" y="30" width="32" height="5" fill="#b91c1c" />
      <circle cx="72" cy="58" r="3" fill="#1f2937" />
      <circle cx="88" cy="58" r="3" fill="#1f2937" />
      <polygon points="80,64 98,68 80,70" fill="#f97316" />
      <path d="M58 82 Q80 92 102 82 L104 90 Q80 100 56 90 Z" fill="#b91c1c" />
      <rect x="92" y="86" width="10" height="24" rx="3" fill="#b91c1c" />
      <circle cx="80" cy="104" r="3.5" fill="#1f2937" />
      <circle cx="80" cy="118" r="3.5" fill="#1f2937" />
      <path d="M48 104 L22 86 M30 92 L22 96" stroke="#7c2d12" strokeWidth="4" strokeLinecap="round" />
      <path d="M112 104 L138 86 M130 92 L140 94" stroke="#7c2d12" strokeWidth="4" strokeLinecap="round" />
    </svg>
  );
}

function BellsScene() {
  return (
    <svg viewBox="0 0 160 160" className="h-full w-full">
      <path d="M40 34 Q80 50 120 34" stroke="#166534" strokeWidth="10" strokeLinecap="round" fill="none" />
      <g className="xmas-bell" style={{ transformOrigin: '60px 44px' }}>
        <path d="M60 44 C38 50 40 92 28 108 L92 108 C80 92 82 50 60 44 Z" fill="#facc15" stroke="#b45309" strokeWidth="3" />
        <circle cx="60" cy="114" r="7" fill="#b45309" />
      </g>
      <g className="xmas-bell" style={{ transformOrigin: '100px 44px', animationDelay: '0.3s' }}>
        <path d="M100 44 C78 50 80 92 68 108 L132 108 C120 92 122 50 100 44 Z" fill="#fbbf24" stroke="#b45309" strokeWidth="3" />
        <circle cx="100" cy="114" r="7" fill="#b45309" />
      </g>
      <path d="M80 30 C62 10 52 30 80 38 C108 30 98 10 80 30 Z" fill="#dc2626" />
      <path d="M78 38 L66 60 M82 38 L94 60" stroke="#dc2626" strokeWidth="6" strokeLinecap="round" />
      <circle cx="80" cy="34" r="6" fill="#b91c1c" />
      <path d="M60 136 Q80 128 100 136" stroke="#fde68a" strokeWidth="2" fill="none" strokeDasharray="2 6" />
    </svg>
  );
}

const SCENES = [
  { label: 'Árbol de Navidad', Component: TreeScene },
  { label: 'Regalos', Component: GiftsScene },
  { label: 'Muñeco de nieve', Component: SnowmanScene },
  { label: 'Campanas navideñas', Component: BellsScene }
];

export function ChristmasScenes() {
  const [index, setIndex] = useState(0);
  useEffect(() => {
    if (prefersReducedMotion()) return undefined;
    const id = setInterval(() => setIndex((i) => (i + 1) % SCENES.length), 4000);
    return () => clearInterval(id);
  }, []);
  const scene = SCENES[index];
  return (
    <div className="flex flex-col items-center gap-2">
      <button
        type="button"
        onClick={() => setIndex((i) => (i + 1) % SCENES.length)}
        className="relative h-36 w-36 shrink-0 cursor-pointer overflow-hidden rounded-full border-4 border-amber-300 bg-gradient-to-b from-[#fff7ed] to-[#fde2e2] shadow-[0_0_24px_rgba(252,211,77,0.55)] transition hover:scale-105 lg:h-44 lg:w-44"
        title="Ver otra imagen navideña"
        aria-label={`${scene.label}. Ver otra imagen navideña`}
      >
        {SCENES.map(({ label, Component }, i) => (
          <div
            key={label}
            className={`absolute inset-0 p-3 transition-all duration-700 ${i === index ? 'scale-100 opacity-100' : 'scale-75 opacity-0'}`}
            aria-hidden={i !== index}
          >
            <Component />
          </div>
        ))}
      </button>
      <div className="flex gap-1.5" aria-hidden="true">
        {SCENES.map(({ label }, i) => (
          <span key={label} className={`h-1.5 rounded-full transition-all ${i === index ? 'w-4 bg-amber-300' : 'w-1.5 bg-white/40'}`} />
        ))}
      </div>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/*  Banner navideño                                                    */
/* ------------------------------------------------------------------ */

export function ChristmasBanner() {
  const [jump, setJump] = useState(false);
  return (
    <section className="relative overflow-hidden bg-gradient-to-b from-[#3b0710] via-[#7a0f1f] to-[#3b0710] text-white">
      <div className="pointer-events-none absolute inset-0 opacity-40" aria-hidden="true">
        {Array.from({ length: 24 }, (_, i) => (
          <span
            key={i}
            className="twinkle-star"
            style={{ left: `${(i * 37) % 100}%`, top: `${(i * 53) % 90}%`, animationDelay: `${(i % 6) * 0.4}s` }}
          />
        ))}
      </div>
      <div className="relative mx-auto flex max-w-6xl items-end gap-4 px-4 pt-4 sm:px-6">
        <button
          type="button"
          onClick={() => {
            setJump(true);
            setTimeout(() => setJump(false), 700);
          }}
          className={`shrink-0 cursor-pointer ${jump ? 'santa-jump' : ''}`}
          title="¡Saluda a Papá Noel!"
          aria-label="Papá Noel"
        >
          <SantaFigure className="h-28 w-24 sm:h-36 sm:w-32" />
        </button>
        <div className="pb-4">
          <p className="font-serif text-2xl font-black tracking-tight text-amber-300 sm:text-4xl">
            ¡Feliz Navidad! <span aria-hidden="true">🎄</span>
          </p>
          <p className="mt-1 font-serif text-lg font-bold italic text-white sm:text-2xl">
            ✨ Feliz y próspero año 2027 ✨
          </p>
          <p className="mt-1 max-w-xl text-sm text-rose-100 sm:text-base">
            Papá Noel ya viene con su trineo cargado de premios. Consulta tu boleta y prepárate para el gran sorteo navideño.
          </p>
        </div>
        <div className="ml-auto hidden pb-4 sm:flex items-end gap-3">
          <span className="ornament-swing hidden text-4xl lg:inline-block" aria-hidden="true">🎁</span>
          <ChristmasScenes />
          <span className="ornament-swing hidden text-4xl lg:inline-block" style={{ animationDelay: '0.8s' }} aria-hidden="true">🔔</span>
        </div>
      </div>
      <div className="snow-ground" aria-hidden="true" />
    </section>
  );
}
