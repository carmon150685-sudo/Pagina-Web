CREATE TABLE "admin_sessions" (
	"token" text PRIMARY KEY,
	"created_at" timestamp DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "documents" (
	"collection" text,
	"id" text,
	"data" jsonb NOT NULL,
	"updated_at" timestamp DEFAULT now() NOT NULL,
	CONSTRAINT "documents_pkey" PRIMARY KEY("collection","id")
);
