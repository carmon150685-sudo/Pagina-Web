import type { Config } from "@netlify/functions";
import { and, eq, lt } from "drizzle-orm";
import { randomBytes } from "node:crypto";
import { db } from "../../db/index.js";
import { documents, adminSessions } from "../../db/schema.js";

const COLLECTIONS = new Set(["rifa_tickets", "rifa_winners", "rifa_config"]);
const CONFIG_ID = "main_settings";
const DEFAULT_PIN = "1234";
const SESSION_MS = 7 * 24 * 60 * 60 * 1000;

const json = (body: unknown, status = 200) =>
  Response.json(body, { status, headers: { "Cache-Control": "no-store" } });

async function getStoredPin(): Promise<string> {
  const [row] = await db
    .select()
    .from(documents)
    .where(and(eq(documents.collection, "rifa_config"), eq(documents.id, CONFIG_ID)));
  const pin = (row?.data as Record<string, unknown> | undefined)?.adminPin;
  return pin ? String(pin) : DEFAULT_PIN;
}

async function isAdmin(req: Request): Promise<boolean> {
  const auth = req.headers.get("authorization") || "";
  const token = auth.startsWith("Bearer ") ? auth.slice(7) : "";
  if (!token) return false;
  const [session] = await db.select().from(adminSessions).where(eq(adminSessions.token, token));
  if (!session) return false;
  return Date.now() - session.createdAt.getTime() < SESSION_MS;
}

function publicData(collection: string, data: Record<string, unknown>) {
  if (collection !== "rifa_config") return data;
  const { adminPin: _hidden, ...rest } = data;
  return rest;
}

export default async (req: Request) => {
  const url = new URL(req.url);
  const parts = url.pathname.replace(/^\/api\/?/, "").split("/").filter(Boolean).map(decodeURIComponent);

  try {
    // POST /api/admin/login  { pin }
    if (parts[0] === "admin" && parts[1] === "login" && req.method === "POST") {
      const { pin } = (await req.json().catch(() => ({}))) as { pin?: string };
      const stored = await getStoredPin();
      if (!pin || String(pin).trim() !== stored) {
        await new Promise((r) => setTimeout(r, 800));
        return json({ ok: false }, 401);
      }
      const token = randomBytes(32).toString("hex");
      await db.delete(adminSessions).where(lt(adminSessions.createdAt, new Date(Date.now() - SESSION_MS)));
      await db.insert(adminSessions).values({ token });
      return json({ ok: true, token, pin: stored });
    }

    // GET /api/admin/session -> validates a stored token
    if (parts[0] === "admin" && parts[1] === "session" && req.method === "GET") {
      if (!(await isAdmin(req))) return json({ ok: false }, 401);
      return json({ ok: true, pin: await getStoredPin() });
    }

    if (parts[0] !== "collections" || !parts[1] || !COLLECTIONS.has(parts[1])) {
      return json({ error: "Not found" }, 404);
    }
    const collection = parts[1];
    const id = parts[2];

    if (req.method === "GET" && !id) {
      const rows = await db.select().from(documents).where(eq(documents.collection, collection));
      return json(rows.map((r) => ({ id: r.id, data: publicData(collection, r.data as Record<string, unknown>) })));
    }

    if (!id) return json({ error: "Missing id" }, 400);
    if (!(await isAdmin(req))) return json({ error: "Unauthorized" }, 401);

    if (req.method === "PUT") {
      let data = (await req.json()) as Record<string, unknown>;
      if (!data || typeof data !== "object" || Array.isArray(data)) return json({ error: "Invalid body" }, 400);
      if (collection === "rifa_config") {
        // Keep the existing PIN unless a new non-empty one is provided
        const newPin = data.adminPin ? String(data.adminPin).trim() : "";
        data = { ...data, adminPin: newPin || (await getStoredPin()) };
      }
      await db
        .insert(documents)
        .values({ collection, id, data })
        .onConflictDoUpdate({
          target: [documents.collection, documents.id],
          set: { data, updatedAt: new Date() },
        });
      return json({ ok: true });
    }

    if (req.method === "DELETE") {
      await db.delete(documents).where(and(eq(documents.collection, collection), eq(documents.id, id)));
      return json({ ok: true });
    }

    return json({ error: "Method not allowed" }, 405);
  } catch (err) {
    console.error(err);
    return json({ error: "Server error" }, 500);
  }
};

export const config: Config = {
  path: ["/api/*"],
};
