import { pgTable, text, jsonb, timestamp, primaryKey } from "drizzle-orm/pg-core";

// Generic document store: each row is one record (ticket, winner or config)
// identified by its collection name and document id.
export const documents = pgTable(
  "documents",
  {
    collection: text().notNull(),
    id: text().notNull(),
    data: jsonb().notNull(),
    updatedAt: timestamp("updated_at").defaultNow().notNull(),
  },
  (t) => [primaryKey({ columns: [t.collection, t.id] })]
);

// Admin sessions created after a successful PIN verification.
export const adminSessions = pgTable("admin_sessions", {
  token: text().primaryKey(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});
